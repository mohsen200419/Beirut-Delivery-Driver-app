# -*- coding: utf-8 -*-
"""
مولّد موقع «دنيا التطبيقات».
عدّل الإعدادات التالية ثم شغّل:   python3 build.py
"""
import os, sys, json, html, datetime, shutil
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))
from apps_data import APPS, CATS, PLATFORM_LABEL
from articles_1 import ARTICLES_1
from articles_2 import ARTICLES_2
from articles_3 import ARTICLES_3

# ======================= الإعدادات (عدّلها) =======================
SITE_NAME = "دنيا التطبيقات"
SITE_URL = "https://example.com"          # ← ضع دومينك الحقيقي بدون / في الآخر
CONTACT_EMAIL = "contact@example.com"      # ← ضع بريدك الحقيقي (ويفضل بريد بدومينك)
ADSENSE_CLIENT = ""                        # ← عند التقديم لـ AdSense: ca-pub-XXXXXXXXXXXXXXXX (يضيف كود التحقق فقط)
ADSENSE_SLOT = ""                          # ← بعد القبول فقط: رقم وحدة إعلانية (يُظهر الإعلانات)
LAST_UPDATE = "12 أكتوبر 2026"
TODAY = "2026-10-12"
# ==================================================================

OUT = os.path.dirname(os.path.abspath(__file__))
ARTICLES = ARTICLES_1 + ARTICLES_2 + ARTICLES_3
ARTICLES.sort(key=lambda a: a["date"], reverse=True)
APP_BY_ID = {a["id"]: a for a in APPS}
ART_BY_SLUG = {a["slug"]: a for a in ARTICLES}
ADS_ON = bool(ADSENSE_CLIENT and ADSENSE_SLOT)

esc = html.escape

def write(name, content):
    with open(os.path.join(OUT, name), "w", encoding="utf-8") as f:
        f.write(content)

NAV = [("index.html", "الرئيسية"), ("apps.html", "التطبيقات والألعاب"),
       ("articles.html", "المقالات"), ("about.html", "من نحن"), ("contact.html", "اتصل بنا")]

def head(title, desc, path, og_type="website", jsonld=None, noindex=False):
    full_title = title if title.endswith(SITE_NAME) else f"{title} | {SITE_NAME}"
    url = f"{SITE_URL}/{path}" if path != "index.html" else f"{SITE_URL}/"
    ads = ""
    if ADSENSE_CLIENT:
        ads = f'<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={ADSENSE_CLIENT}" crossorigin="anonymous"></script>'
    ld = f'<script type="application/ld+json">{json.dumps(jsonld, ensure_ascii=False)}</script>' if jsonld else ""
    robots = '<meta name="robots" content="noindex">' if noindex else ""
    return f"""<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{esc(full_title)}</title>
<meta name="description" content="{esc(desc)}">
{robots}
<link rel="canonical" href="{url}">
<meta property="og:type" content="{og_type}">
<meta property="og:title" content="{esc(full_title)}">
<meta property="og:description" content="{esc(desc)}">
<meta property="og:url" content="{url}">
<meta property="og:site_name" content="{SITE_NAME}">
<meta property="og:locale" content="ar_AR">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🛒</text></svg>">
{ads}
{ld}
</head>
<body>
"""

def header(active=""):
    items = "".join(f'<li><a href="{h}"{" class=active" if h == active else ""}>{t}</a></li>' for h, t in NAV)
    return f"""<a class="skip" href="#main">تخطَّ إلى المحتوى</a>
<header>
  <div class="container nav">
    <a class="logo" href="index.html"><span class="mark">🛒</span> {SITE_NAME}</a>
    <nav aria-label="القائمة الرئيسية"><ul class="nav-links">{items}</ul></nav>
    <button class="burger" aria-label="القائمة">☰</button>
  </div>
</header>
<main id="main">
"""

FOOTER = f"""</main>
<footer>
  <div class="container">
    <div class="foot-grid">
      <div>
        <a class="logo" href="index.html" style="margin-bottom:12px"><span class="mark">🛒</span> {SITE_NAME}</a>
        <p>موقع عربي مستقل يقدم أدلة ومراجعات للتطبيقات والألعاب، مع روابط تؤدي مباشرة إلى المتاجر الرسمية (Google Play، App Store، Steam، Microsoft Store).</p>
      </div>
      <div>
        <h4>أقسام الموقع</h4>
        <ul>
          <li><a href="apps.html?cat=games-mobile">ألعاب موبايل</a></li>
          <li><a href="apps.html?cat=apps-mobile">تطبيقات موبايل</a></li>
          <li><a href="apps.html?cat=games-pc">ألعاب PC — Steam</a></li>
          <li><a href="apps.html?cat=ms-apps">تطبيقات ويندوز</a></li>
        </ul>
      </div>
      <div>
        <h4>عن الموقع</h4>
        <ul>
          <li><a href="articles.html">المقالات</a></li>
          <li><a href="about.html">من نحن</a></li>
          <li><a href="editorial-policy.html">سياسة التحرير</a></li>
          <li><a href="contact.html">اتصل بنا</a></li>
        </ul>
      </div>
      <div>
        <h4>قانوني</h4>
        <ul>
          <li><a href="privacy.html">سياسة الخصوصية</a></li>
          <li><a href="terms.html">شروط الاستخدام</a></li>
        </ul>
      </div>
    </div>
    <div class="copy">© 2026 {SITE_NAME} — جميع أسماء التطبيقات والألعاب وشعاراتها ملك لأصحابها، ولا ينتمي هذا الموقع إلى أي منهم.</div>
  </div>
</footer>
<script src="js/main.js"></script>
</body>
</html>
"""

def ad_unit():
    if not ADS_ON:
        return ""
    return f"""<div class="ad-wrap" aria-label="إعلان"><span class="ad-label">إعلان</span>
<ins class="adsbygoogle" style="display:block" data-ad-client="{ADSENSE_CLIENT}" data-ad-slot="{ADSENSE_SLOT}" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({{}});</script></div>"""

def store_btns(links):
    meta = {"play": ("gp", "▶"), "ios": ("as", ""), "steam": ("st", "🎮"), "ms": ("ms", "⊞")}
    out = ""
    for k in ("play", "ios", "steam", "ms"):
        if k in links:
            cls, ic = meta[k]
            out += f'<a class="store-btn {cls}" href="{links[k]}" target="_blank" rel="noopener noreferrer nofollow"><span class="ic">{ic}</span>{PLATFORM_LABEL[k]}</a>'
    return f'<div class="dl-btns">{out}</div>'

def app_card(a):
    return f"""<article class="card" data-cat="{a['cat']}" data-name="{esc(a['name'].lower())} {esc(a['desc'])}">
  <div class="card-top">
    <div class="icon" style="--grad:{a['grad']}" aria-hidden="true">{a['icon']}</div>
    <div><h3><a href="app-{a['id']}.html">{esc(a['name'])}</a></h3><span class="badge-cat">{CATS[a['cat']]}</span></div>
  </div>
  <p class="desc">{esc(a['desc'])}</p>
  <div class="meta"><span>💰 {esc(a['price'])}</span></div>
  <div class="card-actions"><a class="more" href="app-{a['id']}.html">اقرأ المراجعة ←</a></div>
  {store_btns(a['links'])}
</article>"""

def article_card(a):
    return f"""<article class="article-card">
  <div class="article-meta"><span>🏷️ {a['tag']}</span><span>📅 {a['date']}</span><span>⏱️ {a['minutes']} د</span></div>
  <h3><a href="article-{a['slug']}.html">{esc(a['title'])}</a></h3>
  <p>{esc(a['excerpt'])}</p>
  <a href="article-{a['slug']}.html">اقرأ المقال ←</a>
</article>"""

def org_ld():
    return {"@context": "https://schema.org", "@type": "WebSite", "name": SITE_NAME, "url": SITE_URL + "/", "inLanguage": "ar"}

# ---------------------------------------------------------------- الرئيسية
def build_index():
    feat = ["toe3", "pubgm", "minecraft", "capcut", "cs2", "whatsapp"]
    cards = "".join(app_card(APP_BY_ID[i]) for i in feat)
    arts = "".join(article_card(a) for a in ARTICLES[:6])
    page = head(f"{SITE_NAME} — أدلة ومراجعات التطبيقات والألعاب",
                "أدلة عربية عملية ومراجعات للتطبيقات والألعاب: الأمان، الأداء، الرقابة الأبوية، مع روابط رسمية إلى Google Play وApp Store وSteam.",
                "index.html", jsonld=org_ld())
    page += header("index.html")
    page += f"""
<div class="hero">
  <div class="container">
    <h1>أدلة ومراجعات <span>التطبيقات والألعاب</span><br>بالعربية وبدون تعقيد</h1>
    <p>نكتب أدلة عملية عن الأمان والأداء والمشتريات والرقابة الأبوية، ونراجع التطبيقات والألعاب المشهورة، ونضع الروابط الرسمية للمتاجر ليصل إليها القارئ مباشرة.</p>
    <form class="search-box" id="searchForm" role="search">
      <input type="search" id="searchQ" placeholder="ابحث عن لعبة أو تطبيق… مثال: Minecraft" aria-label="بحث">
      <button type="submit">بحث</button>
    </form>
    <div class="chips">
      <a class="chip" href="apps.html?cat=games-mobile">🎮 ألعاب موبايل</a>
      <a class="chip" href="apps.html?cat=apps-mobile">📱 تطبيقات موبايل</a>
      <a class="chip" href="apps.html?cat=games-pc">🖥️ ألعاب Steam</a>
      <a class="chip" href="articles.html">📝 المقالات</a>
    </div>
    <div class="stats">
      <div><b>{len(APPS)}</b><span>مراجعة تطبيق ولعبة</span></div>
      <div><b>{len(ARTICLES)}</b><span>دليل ومقال</span></div>
      <div><b>4</b><span>متاجر رسمية</span></div>
    </div>
  </div>
</div>
<div class="container">
  <section>
    <div class="sec-title"><h2>📝 أحدث الأدلة والمقالات</h2><a href="articles.html">كل المقالات ←</a></div>
    <div class="grid wide">{arts}</div>
  </section>
  {ad_unit()}
  <section>
    <div class="sec-title"><h2>🔥 مراجعات مختارة</h2><a href="apps.html">عرض الكل ←</a></div>
    <div class="grid">{cards}</div>
  </section>
  <section class="about-strip">
    <h2>كيف نعمل؟</h2>
    <p>نكتب المحتوى بأنفسنا ولا ننسخه، ونوضح مصادرنا وحدودنا. لا نستضيف أي ملفات تطبيقات، وكل أزرار التحميل تفتح صفحة المتجر الرسمي. تعرف على <a href="editorial-policy.html">سياسة التحرير</a> و<a href="about.html">من نحن</a>.</p>
  </section>
</div>
"""
    page += FOOTER
    write("index.html", page)

# ---------------------------------------------------------------- التطبيقات
def build_apps_page():
    chips = '<button class="chip active" data-cat="all">الكل</button>' + "".join(
        f'<button class="chip" data-cat="{k}">{v}</button>' for k, v in CATS.items())
    cards = "".join(app_card(a) for a in APPS)
    page = head("التطبيقات والألعاب — مراجعات وروابط رسمية",
                "مراجعات عربية للتطبيقات والألعاب المشهورة على أندرويد وiOS وSteam، مع روابط رسمية إلى المتاجر.", "apps.html")
    page += header("apps.html")
    page += f"""
<div class="container" style="padding-top:36px">
  <div class="breadcrumb"><a href="index.html">الرئيسية</a> / التطبيقات والألعاب</div>
  <div class="sec-title"><h2>🛒 كل التطبيقات والألعاب</h2></div>
  <p class="lead">لكل عنصر هنا صفحة مراجعة تشرح ما هو ولمن يناسب وما ننصح به قبل التثبيت، مع الروابط الرسمية.</p>
  <div class="filters">
    <input type="search" id="catalogSearch" placeholder="ابحث هنا…" aria-label="ابحث في التطبيقات">
    <div class="chip-row">{chips}</div>
  </div>
  <div class="grid" id="catalogGrid">{cards}</div>
  <p id="noResults" class="muted center" hidden>لا توجد نتائج مطابقة لبحثك.</p>
</div>
"""
    page += FOOTER
    write("apps.html", page)

def build_app_pages():
    for a in APPS:
        rel_apps = [x for x in APPS if x["cat"] == a["cat"] and x["id"] != a["id"]][:3]
        if len(rel_apps) < 3:
            rel_apps += [x for x in APPS if x["id"] != a["id"] and x not in rel_apps][: 3 - len(rel_apps)]
        arts = "".join(article_card(ART_BY_SLUG[s]) for s in a["related"])
        platforms = " · ".join(PLATFORM_LABEL[k] for k in a["links"] if k in PLATFORM_LABEL)
        tips = "".join(f"<li>{esc(t)}</li>" for t in a["tips"])
        ld = {"@context": "https://schema.org", "@type": "WebPage", "name": f"مراجعة {a['name']}",
              "url": f"{SITE_URL}/app-{a['id']}.html", "inLanguage": "ar",
              "about": {"@type": "SoftwareApplication", "name": a["name"], "applicationCategory": CATS[a["cat"]]}}
        page = head(f"{a['name']} — مراجعة وروابط التحميل الرسمية", f"{a['desc']} مراجعة عربية: ما هو، لمن يناسب، ونصائح قبل التثبيت.",
                    f"app-{a['id']}.html", jsonld=ld)
        page += header("apps.html")
        page += f"""
<div class="container" style="padding-top:36px">
  <div class="article-body">
    <div class="breadcrumb"><a href="index.html">الرئيسية</a> / <a href="apps.html">التطبيقات والألعاب</a> / {esc(a['name'])}</div>
    <div class="app-hero">
      <div class="icon big" style="--grad:{a['grad']}" aria-hidden="true">{a['icon']}</div>
      <div><h1>{esc(a['name'])}</h1><p class="muted">{esc(a['desc'])}</p></div>
    </div>
    <table class="info-table">
      <tr><th>الفئة</th><td>{CATS[a['cat']]}</td></tr>
      <tr><th>المطوّر / الناشر</th><td>{esc(a['dev'])}</td></tr>
      <tr><th>السعر</th><td>{esc(a['price'])}</td></tr>
      <tr><th>المنصات</th><td>{platforms}</td></tr>
    </table>
    <h2>ما هو {esc(a['name'])}؟</h2>
    <p>{esc(a['about'])}</p>
    <h2>لمن يناسب؟</h2>
    <p>{esc(a['who'])}</p>
    <h2>نصائح قبل التثبيت والاستخدام</h2>
    <ul>{tips}</ul>
    {ad_unit()}
    <h2>الروابط الرسمية</h2>
    <p>تفتح الأزرار التالية صفحة {esc(a['name'])} في المتجر الرسمي مباشرة. تحقق دائماً من اسم المطوّر ({esc(a['dev'])}) قبل التثبيت، وانتبه لأن السعر والتوفر قد يختلفان بحسب بلدك.</p>
    {store_btns(a['links'])}
    <p class="muted small">ملاحظة: هذه المراجعة معلوماتية ولا تغني عن قراءة صفحة التطبيق الرسمية. قد تتغير الميزات والأسعار مع التحديثات. آخر مراجعة: {LAST_UPDATE}.</p>
  </div>
  <section>
    <div class="sec-title"><h2>أدلة ذات صلة</h2></div>
    <div class="grid wide">{arts}</div>
  </section>
  <section>
    <div class="sec-title"><h2>قد يهمك أيضاً</h2></div>
    <div class="grid">{"".join(app_card(x) for x in rel_apps)}</div>
  </section>
</div>
"""
        page += FOOTER
        write(f"app-{a['id']}.html", page)

# ---------------------------------------------------------------- المقالات
def build_articles_page():
    page = head("المقالات والأدلة — نصائح الأمان والأداء والألعاب",
                "أدلة عربية عملية: أمان التطبيقات، التحقق بخطوتين، الرقابة الأبوية، تحسين أداء الألعاب، المشتريات والاشتراكات.", "articles.html")
    page += header("articles.html")
    page += f"""
<div class="container" style="padding-top:36px">
  <div class="breadcrumb"><a href="index.html">الرئيسية</a> / المقالات</div>
  <div class="sec-title"><h2>📝 المقالات والأدلة</h2></div>
  <p class="lead">أدلة كتبناها بأسلوب مبسط وبخطوات عملية. نحدّثها عند تغير المعلومات.</p>
  <div class="grid wide">{"".join(article_card(a) for a in ARTICLES)}</div>
</div>
"""
    page += FOOTER
    write("articles.html", page)

def split_ad(body):
    if not ADS_ON:
        return body
    idx = [i for i in range(len(body)) if body.startswith("<h2>", i)]
    if len(idx) >= 3:
        p = idx[2]
        return body[:p] + ad_unit() + body[p:]
    return body

def build_article_pages():
    for a in ARTICLES:
        sug = "".join(app_card(APP_BY_ID[i]) for i in a["apps"])
        others = [x for x in ARTICLES if x["slug"] != a["slug"] and x["tag"] == a["tag"]][:2]
        if len(others) < 2:
            others += [x for x in ARTICLES if x["slug"] != a["slug"] and x not in others][: 2 - len(others)]
        ld = {"@context": "https://schema.org", "@type": "Article", "headline": a["title"], "description": a["excerpt"],
              "datePublished": a["date"], "dateModified": TODAY, "inLanguage": "ar",
              "author": {"@type": "Organization", "name": f"فريق تحرير {SITE_NAME}"},
              "publisher": {"@type": "Organization", "name": SITE_NAME},
              "mainEntityOfPage": f"{SITE_URL}/article-{a['slug']}.html"}
        page = head(a["title"], a["excerpt"], f"article-{a['slug']}.html", og_type="article", jsonld=ld)
        page += header("articles.html")
        page += f"""
<div class="container" style="padding-top:36px">
  <div class="article-body">
    <div class="breadcrumb"><a href="index.html">الرئيسية</a> / <a href="articles.html">المقالات</a> / {a['tag']}</div>
    <article>
      <h1>{esc(a['title'])}</h1>
      <div class="article-meta byline">
        <span>✍️ فريق تحرير {SITE_NAME}</span><span>📅 {a['date']}</span><span>⏱️ {a['minutes']} دقائق قراءة</span><span>🏷️ {a['tag']}</span>
      </div>
      {split_ad(a['body'])}
      <p class="muted small">هذا المقال لأغراض معلوماتية. قد تتغير واجهات التطبيقات والسياسات مع الوقت، فراجع المصدر الرسمي عند الحاجة. تعرف على <a href="editorial-policy.html">سياسة التحرير</a>.</p>
    </article>
    {ad_unit()}
    <h2>تطبيقات مرتبطة بالمقال</h2>
    <div class="grid" style="margin-bottom:30px">{sug}</div>
    <h2>اقرأ أيضاً</h2>
    <div class="grid wide">{"".join(article_card(x) for x in others)}</div>
  </div>
</div>
"""
        page += FOOTER
        write(f"article-{a['slug']}.html", page)

# ---------------------------------------------------------------- الصفحات الثابتة
def legal_page(fname, title, desc, body, active=""):
    page = head(title, desc, fname)
    page += header(active)
    page += f"""
<div class="container" style="padding-top:36px">
  <div class="legal">
    <div class="breadcrumb"><a href="index.html">الرئيسية</a> / {esc(title)}</div>
    <h1>{esc(title)}</h1>
    <p class="updated">آخر تحديث: {LAST_UPDATE}</p>
    {body}
  </div>
</div>
"""
    page += FOOTER
    write(fname, page)

def build_static():
    legal_page("about.html", "من نحن", f"تعرف على {SITE_NAME}: موقع عربي مستقل للأدلة والمراجعات التقنية، وكيف نعمل ولماذا أنشأناه.", f"""
<p>{SITE_NAME} موقع عربي مستقل يقدم أدلة عملية ومراجعات للتطبيقات والألعاب. بدأ الموقع بفكرة بسيطة: كثير من القراء العرب يبحثون عن تطبيق أو لعبة فيصلون إلى مواقع تقدم نسخاً معدلة أو روابط مشبوهة، وقليل من المصادر العربية تشرح لهم كيف يختارون ويؤمّنون ويستخدمون ما يحملونه بأمان.</p>
<h2>ماذا ننشر؟</h2>
<ul>
<li><strong>أدلة عملية:</strong> الأمان، التحقق بخطوتين، الرقابة الأبوية، إدارة الاشتراكات والمشتريات، تحسين أداء الهاتف والألعاب.</li>
<li><strong>مراجعات تعريفية:</strong> صفحات للتطبيقات والألعاب المشهورة تشرح ما هي ولمن تناسب وما ننصح به قبل التثبيت.</li>
<li><strong>روابط رسمية:</strong> أزرار تؤدي مباشرة إلى صفحات المتاجر الرسمية.</li>
</ul>
<h2>ما الذي لا نفعله؟</h2>
<ul>
<li>لا نستضيف ملفات تطبيقات ولا نوزع نسخاً معدلة أو «مهكرة».</li>
<li>لا نعد بأرباح سريعة ولا بمزايا غير مشروعة.</li>
<li>لا ننسخ مقالات الآخرين.</li>
</ul>
<h2>كيف يمول الموقع نفسه؟</h2>
<p>قد يعرض الموقع إعلانات عبر Google AdSense لتغطية تكاليف التشغيل والكتابة. الإعلانات لا تؤثر في ما نكتبه، ونفصلها بوضوح عن المحتوى. اقرأ <a href="editorial-policy.html">سياسة التحرير</a> لمعرفة التفاصيل.</p>
<h2>إخلاء مسؤولية</h2>
<p>جميع أسماء التطبيقات والألعاب وشعاراتها ملك لأصحابها. نحن لسنا المطورين ولا موزعين معتمدين لها، ولا نتحمل مسؤولية محتوى التطبيقات أو سلوكها أو مشترياتها داخل المتاجر الرسمية.</p>
<h2>تواصل معنا</h2>
<p>للاقتراحات وتصحيح المعلومات أو الروابط، راسلنا عبر <a href="contact.html">صفحة اتصل بنا</a>.</p>
""", "about.html")

    legal_page("editorial-policy.html", "سياسة التحرير والإعلانات", "كيف نكتب ونراجع محتوى الموقع، وكيف نصحح الأخطاء، وكيف نتعامل مع الإعلانات والروابط.", f"""
<h2>مبادئنا</h2>
<ul>
<li><strong>الأصالة:</strong> نكتب المحتوى بأنفسنا ولا ننسخه من مواقع أخرى.</li>
<li><strong>الفائدة أولاً:</strong> نكتب ما نظن أنه يساعد القارئ فعلاً، لا ما يجلب الزيارات فقط.</li>
<li><strong>الوضوح:</strong> نذكر حدود معلوماتنا، وننبه إلى أن الأسعار والتوفر والواجهات تتغير.</li>
</ul>
<h2>كيف نختار ما نكتب عنه؟</h2>
<p>نختار تطبيقات وألعاباً معروفة ومتوفرة في المتاجر الرسمية، ونكتب في موضوعات يسأل عنها القراء كثيراً. لا يدفع لنا أحد مقابل ذكر تطبيق أو مراجعته في هذه المرحلة. وإن تغير ذلك فسنوضحه بجانب المحتوى المعني.</p>
<h2>الروابط</h2>
<p>روابط التحميل تؤدي إلى صفحات المتاجر الرسمية. لا نستخدم روابط مختصرة ولا نعدّل وجهات الروابط. نراجع الروابط دورياً وقد يتعطل بعضها بسبب تغييرات خارجة عن إرادتنا؛ إن وجدت رابطاً لا يعمل فأخبرنا.</p>
<h2>الإعلانات</h2>
<ul>
<li>قد نعرض إعلانات من Google AdSense، وتُميّز بكلمة «إعلان».</li>
<li>لا نشجع الزوار على النقر على الإعلانات، ولا نضع إعلانات في صفحات الخصوصية أو الاتصال.</li>
<li>لا يؤثر المعلنون في آرائنا أو في ترتيب المحتوى.</li>
</ul>
<h2>التصحيحات</h2>
<p>إن وجدت خطأ، راسلنا عبر <a href="contact.html">صفحة الاتصال</a> وسنراجعه ونصححه، ونحدّث تاريخ التعديل عند الحاجة.</p>
<h2>محتوى الأطفال والأمان</h2>
<p>لا نروّج لمحتوى غير لائق ولا لبرامج الغش أو الاختراق أو النسخ المقرصنة. نذكر التصنيف العمري للألعاب عند الحاجة وننبه الأهل إلى أدوات الرقابة.</p>
""", "about.html")

    legal_page("privacy.html", "سياسة الخصوصية", f"سياسة خصوصية {SITE_NAME}: البيانات التي قد نجمعها، ملفات الارتباط، وخدمات الأطراف الثالثة مثل Google AdSense.", f"""
<p>نحترم خصوصيتك. توضح هذه الصفحة ما قد يُجمع عند زيارتك {SITE_NAME} وكيف يُستخدم.</p>
<h2>1. المعلومات التي قد نجمعها</h2>
<ul>
<li><strong>بيانات الاستخدام:</strong> مثل الصفحات التي تزورها ونوع المتصفح والجهاز والبلد التقريبي، وتُجمع عادة بصورة مجمعة غير شخصية.</li>
<li><strong>ملفات الارتباط (Cookies):</strong> ملفات صغيرة تخزن في متصفحك لتذكر تفضيلاتك أو لقياس الأداء أو لعرض الإعلانات.</li>
<li><strong>بيانات التواصل:</strong> إذا راسلتنا فنحتفظ برسالتك وبريدك الإلكتروني للرد عليك فقط.</li>
</ul>
<h2>2. Google AdSense والإعلانات</h2>
<p>قد يعرض هذا الموقع إعلانات من Google وشركائها. تستخدم Google وشركاؤها ملفات ارتباط ومعرّفات مشابهة لعرض الإعلانات وقياس أدائها، وقد تعرض إعلانات مخصصة بناءً على زياراتك لهذا الموقع ومواقع أخرى. يمكنك:</p>
<ul>
<li>إدارة الإعلانات المخصصة أو إيقافها من <a href="https://adssettings.google.com" target="_blank" rel="noopener noreferrer">إعدادات إعلانات Google</a>.</li>
<li>الاطلاع على <a href="https://policies.google.com/technologies/partner-sites" target="_blank" rel="noopener noreferrer">كيفية استخدام Google للبيانات عند استخدام مواقع شركائها</a>.</li>
<li>إيقاف ملفات الارتباط لدى بعض الشركاء عبر <a href="https://www.aboutads.info" target="_blank" rel="noopener noreferrer">aboutads.info</a>.</li>
<li>التحكم بملفات الارتباط من إعدادات متصفحك.</li>
</ul>
<p>إن كنت في المنطقة الاقتصادية الأوروبية أو المملكة المتحدة أو سويسرا فقد تظهر لك رسالة للموافقة على ملفات الارتباط قبل عرض الإعلانات المخصصة.</p>
<h2>3. الروابط الخارجية</h2>
<p>يحتوي الموقع على روابط إلى مواقع ومتاجر خارجية. لسنا مسؤولين عن سياسات الخصوصية فيها، ننصحك بقراءتها.</p>
<h2>4. الأطفال</h2>
<p>الموقع غير موجه للأطفال دون 13 عاماً، ولا نجمع عمداً بيانات شخصية منهم. إن علمت أن طفلك أرسل لنا بيانات فراسلنا لنحذفها.</p>
<h2>5. حقوقك</h2>
<p>يمكنك طلب الاطلاع على بيانات التواصل التي أرسلتها لنا أو حذفها بمراسلتنا عبر <a href="contact.html">صفحة الاتصال</a>.</p>
<h2>6. تعديل السياسة</h2>
<p>قد نحدّث هذه الصفحة من وقت لآخر، وسيظهر تاريخ آخر تحديث أعلاها.</p>
<h2>7. التواصل</h2>
<p>لأي سؤال عن الخصوصية راسلنا على: <a href="mailto:{CONTACT_EMAIL}">{CONTACT_EMAIL}</a></p>
""")

    legal_page("terms.html", "شروط الاستخدام", f"شروط استخدام موقع {SITE_NAME}.", f"""
<p>باستخدامك الموقع فأنت توافق على الشروط التالية.</p>
<h2>1. طبيعة الخدمة</h2>
<p>الموقع يقدم محتوى معلوماتياً وروابط إلى المتاجر الرسمية. لا نستضيف ولا نوزع ولا نبيع أي برمجيات.</p>
<h2>2. دقة المعلومات</h2>
<p>نبذل جهدنا للدقة، لكن قد تتغير الأسعار والميزات والسياسات، وقد تحتوي المقالات على أخطاء غير مقصودة. استعمل المعلومات بحسب تقديرك، وارجع إلى المصادر الرسمية عند الحاجة.</p>
<h2>3. الملكية الفكرية</h2>
<p>محتوى المقالات والمراجعات من تأليف فريق الموقع ومحمي بحقوق النشر، ويمنع نسخه كاملاً دون إذن. يجوز الاقتباس القصير مع ذكر المصدر ورابط الصفحة. أسماء التطبيقات والشعارات ملك لأصحابها.</p>
<h2>4. حدود المسؤولية</h2>
<ul>
<li>المتاجر والمطورون الخارجيون مسؤولون عن تطبيقاتهم وأسعارهم وسياساتهم.</li>
<li>لا نضمن توفر أي تطبيق في بلدك أو توافقه مع جهازك.</li>
<li>يقدم الموقع «كما هو» دون ضمانات.</li>
</ul>
<h2>5. الاستخدام المقبول</h2>
<p>يمنع استخدام الموقع لأي غرض مخالف للقانون أو محاولة تعطيله أو النقر على الإعلانات بصورة مصطنعة.</p>
<h2>6. التعديلات</h2>
<p>قد نعدل الشروط من وقت لآخر، واستمرارك في استخدام الموقع يعني موافقتك على النسخة المحدثة.</p>
<h2>7. التواصل</h2>
<p>للاستفسار: <a href="mailto:{CONTACT_EMAIL}">{CONTACT_EMAIL}</a></p>
""")

    # اتصل بنا
    page = head("اتصل بنا", f"تواصل مع فريق {SITE_NAME} لاقتراح موضوع أو تصحيح خطأ أو الإبلاغ عن رابط لا يعمل.", "contact.html")
    page += header("contact.html")
    page += f"""
<div class="container" style="padding-top:36px">
  <div class="legal">
    <div class="breadcrumb"><a href="index.html">الرئيسية</a> / اتصل بنا</div>
    <h1>اتصل بنا</h1>
    <p>يسعدنا تواصلك لاقتراح موضوع، أو لتصحيح معلومة، أو للإبلاغ عن رابط لا يعمل، أو لأي استفسار. نحاول الرد خلال بضعة أيام عمل.</p>
    <p><strong>البريد الإلكتروني:</strong> <a href="mailto:{CONTACT_EMAIL}">{CONTACT_EMAIL}</a></p>
    <h2>أو أرسل رسالة من هنا</h2>
    <form id="contactForm" class="contact-form" data-to="{CONTACT_EMAIL}">
      <label>الاسم<input name="name" required autocomplete="name"></label>
      <label>البريد الإلكتروني<input name="email" type="email" required autocomplete="email"></label>
      <label>الموضوع<input name="subject" required></label>
      <label>رسالتك<textarea name="message" rows="6" required></textarea></label>
      <button type="submit">إرسال</button>
      <p class="muted small">عند الضغط على «إرسال» سيفتح تطبيق البريد لديك برسالة جاهزة لتتأكد منها ثم ترسلها.</p>
    </form>
    <h2>قبل أن تراسلنا</h2>
    <ul>
      <li>لا نقدم دعماً فنياً لتطبيقات معينة؛ تواصل مع الدعم الرسمي للتطبيق.</li>
      <li>لا نستطيع استرجاع حسابات أو مدفوعات؛ راجع <a href="article-refund-google-play-app-store.html">دليل الاسترداد</a>.</li>
      <li>إن كنت مطوراً وتريد تصحيح معلومة عن تطبيقك فأرسل لنا التفاصيل وسنراجعها.</li>
    </ul>
  </div>
</div>
"""
    page += FOOTER
    write("contact.html", page)

    # 404
    page = head("الصفحة غير موجودة", "الصفحة التي تبحث عنها غير موجودة.", "404.html", noindex=True)
    page += header()
    page += """
<div class="container" style="padding:80px 20px;text-align:center">
  <h1 style="font-size:3rem">404</h1>
  <p class="lead">الصفحة التي تبحث عنها غير موجودة أو نُقلت.</p>
  <p><a class="store-btn" href="index.html">العودة للرئيسية</a> <a class="store-btn" href="articles.html">تصفح المقالات</a></p>
</div>
"""
    page += FOOTER
    write("404.html", page)

def build_seo_files():
    urls = ["index.html", "apps.html", "articles.html", "about.html", "editorial-policy.html", "contact.html", "privacy.html", "terms.html"]
    urls += [f"app-{a['id']}.html" for a in APPS] + [f"article-{a['slug']}.html" for a in ARTICLES]
    items = ""
    for u in urls:
        loc = f"{SITE_URL}/" if u == "index.html" else f"{SITE_URL}/{u}"
        items += f"  <url><loc>{loc}</loc><lastmod>{TODAY}</lastmod></url>\n"
    write("sitemap.xml", f'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n{items}</urlset>\n')
    write("robots.txt", f"User-agent: *\nAllow: /\n\nSitemap: {SITE_URL}/sitemap.xml\n")
    if ADSENSE_CLIENT:
        pub = ADSENSE_CLIENT.replace("ca-", "")
        write("ads.txt", f"google.com, {pub}, DIRECT, f08c47fec0942fa0\n")
    elif os.path.exists(os.path.join(OUT, "ads.txt")):
        os.remove(os.path.join(OUT, "ads.txt"))

def main():
    # حذف الصفحات المولّدة القديمة
    for f in os.listdir(OUT):
        if f.endswith(".html"):
            os.remove(os.path.join(OUT, f))
    build_index(); build_apps_page(); build_app_pages()
    build_articles_page(); build_article_pages(); build_static(); build_seo_files()
    n = len([f for f in os.listdir(OUT) if f.endswith(".html")])
    print(f"تم بناء {n} صفحة HTML ({len(APPS)} تطبيق، {len(ARTICLES)} مقال).")
    if "example.com" in SITE_URL or "example.com" in CONTACT_EMAIL:
        print("⚠️ تنبيه: عدّل SITE_URL وCONTACT_EMAIL في أعلى build.py قبل النشر.")
    if not ADS_ON:
        print("ℹ️ الإعلانات مطفأة (ADSENSE_CLIENT/ADSENSE_SLOT فارغان) — هذا هو المطلوب قبل التقديم.")

if __name__ == "__main__":
    main()
