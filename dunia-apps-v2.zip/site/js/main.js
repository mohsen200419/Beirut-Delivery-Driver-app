/* دنيا التطبيقات — سكربت خفيف: القائمة، البحث، الفلاتر، نموذج الاتصال */
(function () {
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };

  var burger = $(".burger"), links = $(".nav-links");
  if (burger && links) burger.addEventListener("click", function () { links.classList.toggle("open"); });

  var sf = $("#searchForm"), sq = $("#searchQ");
  if (sf && sq) sf.addEventListener("submit", function (e) {
    e.preventDefault();
    var v = sq.value.trim();
    if (v) location.href = "apps.html?q=" + encodeURIComponent(v);
  });

  var grid = $("#catalogGrid");
  if (grid) {
    var cards = $$("#catalogGrid .card"), chips = $$(".chip[data-cat]");
    var si = $("#catalogSearch"), none = $("#noResults");
    var cat = "all", q = "";
    var params = new URLSearchParams(location.search);
    if (params.get("cat")) cat = params.get("cat");
    if (params.get("q")) { q = params.get("q").toLowerCase(); if (si) si.value = params.get("q"); }
    var draw = function () {
      var shown = 0;
      cards.forEach(function (c) {
        var ok = (cat === "all" || c.dataset.cat === cat) && (!q || c.dataset.name.indexOf(q) !== -1);
        c.hidden = !ok; if (ok) shown++;
      });
      chips.forEach(function (x) { x.classList.toggle("active", x.dataset.cat === cat); });
      if (none) none.hidden = shown !== 0;
    };
    chips.forEach(function (c) { c.addEventListener("click", function () { cat = c.dataset.cat; draw(); }); });
    if (si) si.addEventListener("input", function () { q = si.value.trim().toLowerCase(); draw(); });
    draw();
  }

  var form = $("#contactForm");
  if (form) form.addEventListener("submit", function (e) {
    e.preventDefault();
    var d = new FormData(form), to = form.dataset.to;
    var body = "الاسم: " + d.get("name") + "\nالبريد: " + d.get("email") + "\n\n" + d.get("message");
    location.href = "mailto:" + to + "?subject=" + encodeURIComponent(d.get("subject")) + "&body=" + encodeURIComponent(body);
  });
})();
