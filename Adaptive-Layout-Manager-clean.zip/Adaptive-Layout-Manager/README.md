# Adaptive Layout Manager

مشروع monorepo يحتوي:
- `artifacts/mobile` — تطبيق الموبايل (Expo / React Native)
- `artifacts/api-server` — السيرفر (API)
- `artifacts/mockup-sandbox` — نسخة تجريبية للتصميم
- `lib/` — كود مشترك (db, api-client, zod schemas)

## التشغيل محلياً

```bash
pnpm install
```

## بناء APK

```bash
cd artifacts/mobile
npx eas login
eas build --platform android --profile preview
```
