import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Linking, Alert, Platform,
} from 'react-native';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import { Order, OrderStatus } from '@/types';
import { useLanguage } from '@/context/LanguageContext';

export const STATUS_CONFIG: Record<OrderStatus, { label: string; labelKey: string; color: string; emoji: string }> = {
  pending:     { label: 'قيد المراجعة', labelKey: 'statusPending', color: '#f59e0b', emoji: '⏳' },
  accepted:    { label: 'تم القبول',    labelKey: 'statusAccepted', color: '#3b82f6', emoji: '✅' },
  in_delivery: { label: 'قيد التوصيل', labelKey: 'statusInDelivery', color: '#8b5cf6', emoji: '🏍️' },
  delivered:   { label: 'تم التسليم',  labelKey: 'statusDelivered', color: '#22c55e', emoji: '📦' },
  cancelled:   { label: 'ملغى',         labelKey: 'statusCancelled', color: '#6b7280', emoji: '❌' },
};

const NEXT_ACTION: Partial<Record<OrderStatus, { label: string; labelKey: string; nextStatus: OrderStatus; msgKey: string }>> = {
  pending:     { label: 'قبول',         labelKey: 'actionAccept', nextStatus: 'accepted',    msgKey: 'confirm' },
  accepted:    { label: '🏍️ في الطريق', labelKey: 'actionOnWay', nextStatus: 'in_delivery', msgKey: 'onway' },
  in_delivery: { label: '✅ تم التسليم', labelKey: 'actionDelivered', nextStatus: 'delivered',   msgKey: 'done' },
};

function buildWhatsAppMessage(msgKey: string, customerName: string, serviceName: string, address: string, totalStr: string): string {
  if (msgKey === 'confirm') {
    return `أهلاً ${customerName} 👋\nتم استلام طلبك (${serviceName}) وجاري التجهيز 🚀\nإجمالي الطلب: ${totalStr}\nشكراً لثقتك!`;
  }
  if (msgKey === 'onway') {
    return `مرحباً ${customerName} 🏍️\nالسائق في طريقه إليك الآن!\n${address ? `العنوان: ${address}` : ''}\nيرجى التواجد في العنوان.`;
  }
  return `مرحباً ${customerName} 📦\nتم توصيل طلبك بنجاح ✅\nشكراً لاختيارك خدماتنا!\nنتطلع لخدمتك مجدداً 🙏`;
}

interface Props {
  order: Order;
  zoneName: string;
  serviceName: string;
  onStatusChange: (id: string, status: OrderStatus) => void;
  onDelete: (id: string) => void;
}

export function OrderCard({ order, zoneName, serviceName, onStatusChange, onDelete }: Props) {
  const colors = useColors();
  const { t } = useLanguage();
  const cfg = STATUS_CONFIG[order.status];
  const action = NEXT_ACTION[order.status];

  // Send WhatsApp TO the customer using their phone number
  const sendWhatsApp = async () => {
    if (!action) return;
    const customerPhone = order.phone.replace(/\D/g, '');
    if (!customerPhone) {
      Alert.alert(t('noPhone'), t('noPhoneContinue'), [
        { text: t('no'), style: 'cancel' },
        { text: t('yes'), onPress: () => onStatusChange(order.id, action.nextStatus) },
      ]);
      return;
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    onStatusChange(order.id, action.nextStatus);
    const totalStr = `$${order.total_usd.toFixed(2)} / ${order.total_lbp.toLocaleString()} ل.ل.`;
    const msg = encodeURIComponent(buildWhatsAppMessage(action.msgKey, order.customer_name, serviceName, order.address, totalStr));
    const waUrl = `whatsapp://send?phone=${customerPhone}&text=${msg}`;
    const webUrl = `https://wa.me/${customerPhone}?text=${msg}`;
    const supported = await Linking.canOpenURL(waUrl);
    Linking.openURL(supported ? waUrl : webUrl);
  };

  const callCustomer = () => {
    const phone = order.phone.replace(/\D/g, '');
    if (!phone) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Linking.openURL(`tel:${phone}`);
  };

  const navigateToAddress = () => {
    if (!order.address) return;
    const addr = encodeURIComponent(order.address + ' بيروت لبنان');
    Linking.openURL(`https://maps.google.com/?q=${addr}`);
  };

  const confirmDelete = () => {
    Alert.alert(t('deleteOrder'), `"${order.customer_name}"`, [
      { text: t('cancel'), style: 'cancel' },
      { text: t('delete'), style: 'destructive', onPress: () => onDelete(order.id) },
    ]);
  };

  const timeStr = new Date(order.created_at).toLocaleTimeString('ar-LB', {
    hour: '2-digit', minute: '2-digit',
  });

  return (
    <TouchableOpacity
      activeOpacity={0.88}
      onPress={() => router.push({ pathname: '/order-detail', params: { id: order.id } })}
    >
      <View style={[st.card, { backgroundColor: colors.card, borderColor: colors.border, borderRightColor: cfg.color, borderRightWidth: 3 }]}>
        {/* Status + time */}
        <View style={st.topRow}>
          <View style={[st.badge, { backgroundColor: cfg.color + '20' }]}>
            <Text style={[st.badgeText, { color: cfg.color }]}>{cfg.emoji} {t(cfg.labelKey)}</Text>
          </View>
          <View style={st.topRight}>
            <Text style={[st.time, { color: colors.mutedForeground }]}>{timeStr}</Text>
            <TouchableOpacity onPress={confirmDelete} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <Feather name="trash-2" size={15} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Customer */}
        <Text style={[st.name, { color: colors.foreground }]}>{order.customer_name}</Text>

        <View style={st.metaRow}>
          <Feather name="map-pin" size={12} color={colors.mutedForeground} />
          <Text style={[st.meta, { color: colors.mutedForeground }]} numberOfLines={1}>
            {zoneName}
          </Text>
          {order.address ? (
            <>
              <Text style={[st.dot, { color: colors.border }]}>·</Text>
              <Text style={[st.meta, { color: colors.mutedForeground }]} numberOfLines={1}>
                {order.address}
              </Text>
            </>
          ) : null}
        </View>

        <Text style={[st.service, { color: colors.mutedForeground }]}>
          <Feather name="package" size={12} /> {serviceName}
        </Text>

        {/* Price + actions */}
        <View style={[st.divider, { backgroundColor: colors.border }]} />
        <View style={st.bottomRow}>
          <View>
            <Text style={[st.priceUsd, { color: colors.accent }]}>${order.total_usd.toFixed(2)}</Text>
            <Text style={[st.priceLbp, { color: colors.mutedForeground }]}>
              {order.total_lbp.toLocaleString()} ل.ل.
            </Text>
          </View>
          <View style={st.actions}>
            {order.address ? (
              <TouchableOpacity style={[st.iconBtn, { backgroundColor: colors.surface }]} onPress={navigateToAddress}>
                <Feather name="navigation" size={17} color="#22c55e" />
              </TouchableOpacity>
            ) : null}
            {order.phone ? (
              <TouchableOpacity style={[st.iconBtn, { backgroundColor: colors.surface }]} onPress={callCustomer}>
                <Feather name="phone" size={17} color={colors.primary} />
              </TouchableOpacity>
            ) : null}
            {action ? (
              <TouchableOpacity style={[st.waBtn, { backgroundColor: '#25D366' }]} onPress={sendWhatsApp}>
                <MaterialCommunityIcons name="whatsapp" size={16} color="#fff" />
                <Text style={st.waBtnText}>{t(action.labelKey)}</Text>
              </TouchableOpacity>
            ) : null}
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const st = StyleSheet.create({
  card: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 10,
  },
  topRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  badgeText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  topRight: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  time: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  name: { fontSize: 17, fontFamily: 'Inter_700Bold', marginBottom: 4 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 2, flexWrap: 'wrap' },
  meta: { fontSize: 12, fontFamily: 'Inter_400Regular', flex: 1 },
  dot: { fontSize: 12 },
  service: { fontSize: 12, fontFamily: 'Inter_500Medium', marginTop: 2 },
  divider: { height: 1, marginVertical: 10 },
  bottomRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  priceUsd: { fontSize: 20, fontFamily: 'Inter_700Bold' },
  priceLbp: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  actions: { flexDirection: 'row', gap: 7, alignItems: 'center' },
  iconBtn: { width: 38, height: 38, borderRadius: 19, justifyContent: 'center', alignItems: 'center' },
  waBtn: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 12, paddingVertical: 9, borderRadius: 20, gap: 5,
  },
  waBtnText: { color: '#fff', fontSize: 12, fontFamily: 'Inter_700Bold' },
});
