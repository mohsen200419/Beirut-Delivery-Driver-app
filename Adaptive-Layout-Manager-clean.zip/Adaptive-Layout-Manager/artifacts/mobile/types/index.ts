export interface CustomField {
  id: string;
  label_ar: string;
  label_en: string;
  type: 'text' | 'number';
  required: boolean;
}

export interface Service {
  id: string;
  name_ar: string;
  name_en: string;
  is_active: boolean;
  custom_fields: CustomField[];
}

export interface Zone {
  id: string;
  zone_name_ar: string;
  zone_name_en: string;
  delivery_fee_usd: number;
  delivery_fee_lbp: number;
  is_active: boolean;
}

export type OrderStatus = 'pending' | 'accepted' | 'in_delivery' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  customer_name: string;
  phone: string;
  address: string;
  service_id: string;
  zone_id: string;
  submitted_custom_fields: Record<string, string>;
  item_price_usd: number;
  delivery_fee_usd: number;
  total_usd: number;
  total_lbp: number;
  status: OrderStatus;
  currency: 'USD' | 'LBP';
  created_at: string;
  notes?: string;
}

export type ExpenseType = 'fuel' | 'maintenance' | 'other';

export interface Expense {
  id: string;
  date: string;
  type: ExpenseType;
  amount_usd: number;
  amount_lbp: number;
  notes: string;
}

export interface AppSettings {
  exchange_rate: number;
  whatsapp_number: string;
  owner_name: string;
  language: AppLanguage;
}

export type AppLanguage = 'ar' | 'en' | 'fr';
