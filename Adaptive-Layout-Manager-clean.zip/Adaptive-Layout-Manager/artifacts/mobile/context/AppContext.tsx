import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Service, Zone, Order, Expense, AppSettings, OrderStatus } from '@/types';

const KEYS = {
  SERVICES: '@bd/services',
  ZONES: '@bd/zones',
  ORDERS: '@bd/orders',
  EXPENSES: '@bd/expenses',
  SETTINGS: '@bd/settings',
  ONBOARDED: '@bd/onboarded',
};

// No default zones — driver must add their own with custom names & prices
const DEFAULT_ZONES: Zone[] = [];

const DEFAULT_SERVICES: Service[] = [
  {
    id: 's1', name_ar: 'التسوق الإلكتروني', name_en: 'Online Shopping', is_active: true,
    custom_fields: [
      { id: 'cf1', label_ar: 'رقم التتبع', label_en: 'Tracking #', type: 'text', required: true },
    ],
  },
  {
    id: 's2', name_ar: 'توصيل طعام', name_en: 'Food Delivery', is_active: true,
    custom_fields: [
      { id: 'cf2', label_ar: 'اسم المطعم', label_en: 'Restaurant', type: 'text', required: true },
      { id: 'cf3', label_ar: 'تفاصيل الطلب', label_en: 'Order Details', type: 'text', required: false },
    ],
  },
  {
    id: 's3', name_ar: 'وثائق ومستندات', name_en: 'Documents', is_active: true,
    custom_fields: [
      { id: 'cf4', label_ar: 'وصف الوثيقة', label_en: 'Description', type: 'text', required: false },
    ],
  },
  {
    id: 's4', name_ar: 'طرود عامة', name_en: 'General Package', is_active: true,
    custom_fields: [],
  },
];

const DEFAULT_SETTINGS: AppSettings = {
  exchange_rate: 89500,
  whatsapp_number: '',
  owner_name: 'السائق',
  language: 'ar',
};

interface AppContextType {
  services: Service[];
  zones: Zone[];
  orders: Order[];
  expenses: Expense[];
  settings: AppSettings;
  isLoading: boolean;
  isSetupComplete: boolean;
  addOrder: (order: Order) => void;
  updateOrderStatus: (id: string, status: OrderStatus) => void;
  deleteOrder: (id: string) => void;
  addService: (service: Service) => void;
  updateService: (service: Service) => void;
  deleteService: (id: string) => void;
  addZone: (zone: Zone) => void;
  updateZone: (zone: Zone) => void;
  deleteZone: (id: string) => void;
  addExpense: (expense: Expense) => void;
  deleteExpense: (id: string) => void;
  updateSettings: (updates: Partial<AppSettings>) => void;
}

const AppContext = createContext<AppContextType | null>(null);

async function persist(key: string, value: unknown) {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch (_) {}
}

function genId() {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [services, setServices] = useState<Service[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [sRaw, zRaw, oRaw, eRaw, stRaw] = await Promise.all([
          AsyncStorage.getItem(KEYS.SERVICES),
          AsyncStorage.getItem(KEYS.ZONES),
          AsyncStorage.getItem(KEYS.ORDERS),
          AsyncStorage.getItem(KEYS.EXPENSES),
          AsyncStorage.getItem(KEYS.SETTINGS),
        ]);
        setServices(sRaw ? JSON.parse(sRaw) : DEFAULT_SERVICES);
        setZones(zRaw ? JSON.parse(zRaw) : DEFAULT_ZONES);
        setOrders(oRaw ? JSON.parse(oRaw) : []);
        setExpenses(eRaw ? JSON.parse(eRaw) : []);
        const storedSettings = stRaw ? JSON.parse(stRaw) : DEFAULT_SETTINGS;
        setSettings({ ...DEFAULT_SETTINGS, ...storedSettings });
      } catch (_) {
        setServices(DEFAULT_SERVICES);
        setZones(DEFAULT_ZONES);
      } finally {
        setIsLoading(false);
      }
    })();
  }, []);

  // Setup is complete when driver has at least one active zone
  const isSetupComplete = zones.some(z => z.is_active);

  const addOrder = (order: Order) => {
    const next = [order, ...orders];
    setOrders(next);
    persist(KEYS.ORDERS, next);
  };

  const updateOrderStatus = (id: string, status: OrderStatus) => {
    const next = orders.map(o => o.id === id ? { ...o, status } : o);
    setOrders(next);
    persist(KEYS.ORDERS, next);
  };

  const deleteOrder = (id: string) => {
    const next = orders.filter(o => o.id !== id);
    setOrders(next);
    persist(KEYS.ORDERS, next);
  };

  const addService = (service: Service) => {
    const next = [...services, service];
    setServices(next);
    persist(KEYS.SERVICES, next);
  };

  const updateService = (service: Service) => {
    const next = services.map(s => s.id === service.id ? service : s);
    setServices(next);
    persist(KEYS.SERVICES, next);
  };

  const deleteService = (id: string) => {
    const next = services.filter(s => s.id !== id);
    setServices(next);
    persist(KEYS.SERVICES, next);
  };

  const addZone = (zone: Zone) => {
    const next = [...zones, zone];
    setZones(next);
    persist(KEYS.ZONES, next);
  };

  const updateZone = (zone: Zone) => {
    const next = zones.map(z => z.id === zone.id ? zone : z);
    setZones(next);
    persist(KEYS.ZONES, next);
  };

  const deleteZone = (id: string) => {
    const next = zones.filter(z => z.id !== id);
    setZones(next);
    persist(KEYS.ZONES, next);
  };

  const addExpense = (expense: Expense) => {
    const next = [expense, ...expenses];
    setExpenses(next);
    persist(KEYS.EXPENSES, next);
  };

  const deleteExpense = (id: string) => {
    const next = expenses.filter(e => e.id !== id);
    setExpenses(next);
    persist(KEYS.EXPENSES, next);
  };

  const updateSettings = (updates: Partial<AppSettings>) => {
    const next = { ...settings, ...updates };
    setSettings(next);
    persist(KEYS.SETTINGS, next);
  };

  return (
    <AppContext.Provider value={{
      services, zones, orders, expenses, settings, isLoading, isSetupComplete,
      addOrder, updateOrderStatus, deleteOrder,
      addService, updateService, deleteService,
      addZone, updateZone, deleteZone,
      addExpense, deleteExpense,
      updateSettings,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
