# Beirut Delivery — Privacy Policy

**Last updated: August 8, 2026**

Beirut Delivery is a driver and delivery-management app. It is designed to
work locally on the user's device.

## Information stored

The app can store delivery zones, services, orders, customer names, phone
numbers, addresses, expenses, and app settings. This information is stored
locally on the device using the device's local app storage.

## Information sharing

Beirut Delivery does not operate a user account system, advertising system, or
remote analytics service. The app does not send the locally stored data to a
Beirut Delivery server.

When the driver chooses to call a customer, open WhatsApp, or open Google
Maps, the operating system opens the selected third-party app or service. That
service may process information according to its own privacy policy.

## Data deletion

The driver can delete orders, delivery zones, services, and expenses from
within the app. Uninstalling the app removes its local data, subject to the
device's operating-system backup settings.

## Contact

For support or privacy questions, contact the app owner through the support
contact submitted with the store listing.