import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput, Platform, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { KeyboardAwareScrollView } from 'react-native-keyboard-controller';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { useLanguage } from '@/context/LanguageContext';
import { Expense, ExpenseType } from '@/types';

const TYPES: { key: ExpenseType; label: string; icon: string }[] = [
  { key: 'fuel',        label: 'بنزين',   icon: 'gas-station' },
  { key: 'maintenance', label: 'صيانة',   icon: 'wrench' },
  { key: 'other',       label: 'أخرى',    icon: 'cash' },
];

export default function AddExpenseScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { settings, addExpense } = useApp();
  const { t, language } = useLanguage();

  const [type, setType] = useState<ExpenseType>('fuel');
  const [amount, setAmount] = useState('');
  const [expCurrency, setExpCurrency] = useState<'USD' | 'LBP'>('USD');
  const [notes, setNotes] = useState('');

  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 34 : insets.bottom;

  const handleSubmit = () => {
    const amountNum = parseFloat(amount);
    if (!amountNum || amountNum <= 0) {
      Alert.alert(t('warning'), language === 'ar' ? 'يرجى إدخال مبلغ صحيح' : language === 'fr' ? 'Veuillez saisir un montant valide' : 'Please enter a valid amount');
      return;
    }
    const amountUsd = expCurrency === 'USD' ? amountNum : amountNum / settings.exchange_rate;
    const amountLbp = expCurrency === 'LBP' ? amountNum : Math.round(amountNum * settings.exchange_rate);
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    const expense: Expense = {
      id,
      date: new Date().toISOString(),
      type,
      amount_usd: Math.round(amountUsd * 100) / 100,
      amount_lbp: amountLbp,
      notes: notes.trim(),
    };
    addExpense(expense);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.back();
  };

  const amountNum = parseFloat(amount) || 0;
  const equivalentUsd = expCurrency === 'LBP' ? (amountNum / settings.exchange_rate).toFixed(2) : null;
  const equivalentLbp = expCurrency === 'USD' ? Math.round(amountNum * settings.exchange_rate).toLocaleString() : null;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 16, backgroundColor: colors.surface }]}>
        <TouchableOpacity onPress={() => router.back()} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Feather name="x" size={24} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>{t('addExpense')}</Text>
        <View style={{ width: 24 }} />
      </View>

      <KeyboardAwareScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: botPad + 20 }]}
        showsVerticalScrollIndicator={false}
        bottomOffset={20}
      >
        {/* Expense type */}
        <Text style={[styles.label, { color: colors.mutedForeground }]}>{t('expenseType')}</Text>
        <View style={styles.typeRow}>
          {TYPES.map(t => {
            const sel = type === t.key;
            return (
              <TouchableOpacity
                key={t.key}
                style={[styles.typeBtn, {
                  backgroundColor: sel ? colors.destructive + '22' : colors.card,
                  borderColor: sel ? colors.destructive : colors.border,
                }]}
                onPress={() => setType(t.key)}
              >
                <MaterialCommunityIcons
                  name={t.icon as any}
                  size={24}
                  color={sel ? colors.destructive : colors.mutedForeground}
                />
                <Text style={[styles.typeBtnLabel, { color: sel ? colors.destructive : colors.foreground }]}>
                  {t.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Currency */}
        <Text style={[styles.label, { color: colors.mutedForeground }]}>{t('currency')}</Text>
        <View style={styles.currRow}>
          {(['USD', 'LBP'] as const).map(c => (
            <TouchableOpacity
              key={c}
              style={[styles.currBtn, { backgroundColor: expCurrency === c ? colors.primary : colors.card, borderColor: colors.border }]}
              onPress={() => setExpCurrency(c)}
            >
              <Text style={[styles.currBtnText, { color: expCurrency === c ? '#fff' : colors.foreground }]}>{c}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Amount */}
        <Text style={[styles.label, { color: colors.mutedForeground }]}>{t('amount')}</Text>
        <View style={[styles.amountBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.currSymbol, { color: colors.mutedForeground }]}>
            {expCurrency === 'USD' ? '$' : 'ل.ل.'}
          </Text>
          <TextInput
            style={[styles.amountInput, { color: colors.foreground }]}
            value={amount}
            onChangeText={setAmount}
            placeholder="0"
            placeholderTextColor={colors.mutedForeground}
            keyboardType="numeric"
          />
        </View>
        {amountNum > 0 && (
          <Text style={[styles.equivalent, { color: colors.mutedForeground }]}>
            {equivalentLbp ? `= ${equivalentLbp} ل.ل.` : `= $${equivalentUsd}`}
          </Text>
        )}

        {/* Notes */}
        <Text style={[styles.label, { color: colors.mutedForeground }]}>{t('notesOptional')}</Text>
        <View style={[styles.notesBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <TextInput
            style={[styles.notesInput, { color: colors.foreground }]}
            value={notes}
            onChangeText={setNotes}
            placeholder="تفاصيل إضافية..."
            placeholderTextColor={colors.mutedForeground}
            multiline
            numberOfLines={3}
          />
        </View>
      </KeyboardAwareScrollView>

      {/* Footer */}
      <View style={[styles.footer, { paddingBottom: botPad + 8, backgroundColor: colors.background, borderTopColor: colors.border }]}>
        <TouchableOpacity
          style={[styles.submitBtn, { backgroundColor: colors.destructive }]}
          onPress={handleSubmit}
        >
          <Feather name="plus-circle" size={20} color="#fff" />
          <Text style={styles.submitBtnText}>{t('recordExpense')}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 14,
  },
  headerTitle: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  scroll: { padding: 20 },
  label: {
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 10,
    marginTop: 20,
  },
  typeRow: { flexDirection: 'row', gap: 10 },
  typeBtn: {
    flex: 1,
    borderRadius: 12,
    borderWidth: 1.5,
    padding: 14,
    alignItems: 'center',
    gap: 6,
  },
  typeBtnLabel: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  currRow: { flexDirection: 'row', gap: 12 },
  currBtn: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
  },
  currBtnText: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  amountBox: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingVertical: 4,
    gap: 8,
  },
  currSymbol: { fontSize: 22, fontFamily: 'Inter_600SemiBold' },
  amountInput: { flex: 1, fontSize: 32, fontFamily: 'Inter_700Bold', paddingVertical: 14 },
  equivalent: { fontSize: 13, fontFamily: 'Inter_400Regular', marginTop: 6 },
  notesBox: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
  },
  notesInput: { fontSize: 15, fontFamily: 'Inter_400Regular', minHeight: 80, textAlignVertical: 'top' },
  footer: {
    padding: 16,
    borderTopWidth: 1,
  },
  submitBtn: {
    flexDirection: 'row',
    height: 56,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  submitBtnText: { color: '#fff', fontSize: 17, fontFamily: 'Inter_700Bold' },
});
