import React from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  Platform, Linking, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { OrderStatus } from '@/types';
import { STATUS_CONFIG } from '@/components/OrderCard';
import { useLanguage } from '@/context/LanguageContext';

const STATUS_FLOW: Partial<Record<OrderStatus, { next: OrderStatus; labelKey: string; color: string }>> = {
  pending:     { next: 'accepted',    labelKey: 'acceptOrder', color: '#3b82f6' },
  accepted:    { next: 'in_delivery', labelKey: 'startDelivery', color: '#8b5cf6' },
  in_delivery: { next: 'delivered',   labelKey: 'confirmDelivery', color: '#22c55e' },
};

export default function OrderDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { orders, zones, services, settings, updateOrderStatus, deleteOrder } = useApp();
  const { t, language } = useLanguage();

  const order = orders.find(o => o.id === id);
  const zone = zones.find(z => z.id === order?.zone_id);
  const service = services.find(s => s.id === order?.service_id);

  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 34 : insets.bottom;

  if (!order) {
    return (
      <View style={[st.center, { backgroundColor: colors.background }]}>
        <Feather name="alert-circle" size={40} color={colors.mutedForeground} />
        <Text style={[st.notFoundText, { color: colors.mutedForeground }]}>{t('orderNotFound')}</Text>
        <TouchableOpacity
          style={[st.backBtn2, { borderColor: colors.primary }]}
          onPress={() => router.back()}
        >
          <Text style={[st.backBtn2Text, { color: colors.primary }]}>{t('back')}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const cfg = STATUS_CONFIG[order.status];
  const nextStep = STATUS_FLOW[order.status];
  const canAct = order.status !== 'delivered' && order.status !== 'cancelled';

  const advanceStatus = () => {
    if (!nextStep) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    updateOrderStatus(order.id, nextStep.next);
  };

  const cancelOrder = () => {
    Alert.alert(t('cancelOrder'), t('cancelOrderQuestion'), [
      { text: t('no'), style: 'cancel' },
      {
        text: t('cancelOrder'), style: 'destructive',
        onPress: () => { updateOrderStatus(order.id, 'cancelled'); router.back(); },
      },
    ]);
  };

  const deleteOrderConfirm = () => {
    Alert.alert(t('deleteOrder'), t('deleteOrderQuestion'), [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('delete'), style: 'destructive',
        onPress: () => { deleteOrder(order.id); router.back(); },
      },
    ]);
  };

  // Call / WhatsApp TO the customer's phone number
  const callCustomer = () => {
    const phone = order.phone.replace(/\D/g, '');
    if (!phone) { Alert.alert(t('noPhone'), t('noCustomerPhone')); return; }
    Linking.openURL(`tel:${phone}`);
  };

  const whatsappCustomer = async () => {
    const phone = order.phone.replace(/\D/g, '');
    if (!phone) { Alert.alert(t('noPhone'), t('noCustomerPhone')); return; }
    const msg = encodeURIComponent(`مرحباً ${order.customer_name} 👋`);
    const waUrl = `whatsapp://send?phone=${phone}&text=${msg}`;
    const webUrl = `https://wa.me/${phone}?text=${msg}`;
    const ok = await Linking.canOpenURL(waUrl);
    Linking.openURL(ok ? waUrl : webUrl);
  };

  const navigateToAddress = () => {
    if (!order.address) return;
    const q = encodeURIComponent(order.address + ' بيروت لبنان');
    Linking.openURL(`https://maps.google.com/?q=${q}`);
  };

  const createdDate = new Date(order.created_at);
  const dateTimeStr = createdDate.toLocaleDateString(language === 'ar' ? 'ar-LB' : language === 'fr' ? 'fr-LB' : 'en-LB', {
    day: 'numeric', month: 'long', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });

  return (
    <View style={[st.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[st.header, { paddingTop: topPad + 12, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={[st.backCircle, { backgroundColor: colors.secondary }]}
        >
          <Feather name="arrow-right" size={20} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[st.headerTitle, { color: colors.foreground }]}>{t('orderDetails')}</Text>
        <TouchableOpacity
          onPress={deleteOrderConfirm}
          style={[st.backCircle, { backgroundColor: colors.destructive + '22' }]}
        >
          <Feather name="trash-2" size={18} color={colors.destructive} />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={[st.scroll, { paddingBottom: botPad + 120 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Status banner */}
        <View style={[st.statusBanner, { backgroundColor: cfg.color + '18', borderColor: cfg.color + '40' }]}>
          <Text style={[st.statusEmoji]}>{cfg.emoji}</Text>
          <View style={{ flex: 1 }}>
            <Text style={[st.statusLabel, { color: cfg.color }]}>{t(cfg.labelKey)}</Text>
            <Text style={[st.statusDate, { color: colors.mutedForeground }]}>{dateTimeStr}</Text>
          </View>
          <Text style={[st.orderId, { color: colors.mutedForeground }]}>
            #{order.id.slice(-6).toUpperCase()}
          </Text>
        </View>

        {/* Quick contact row */}
        <View style={st.quickRow}>
          <TouchableOpacity
            style={[st.quickBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={callCustomer}
          >
            <Feather name="phone" size={20} color={colors.primary} />
            <Text style={[st.quickBtnLabel, { color: colors.primary }]}>{t('contact')}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[st.quickBtn, { backgroundColor: '#25D36618', borderColor: '#25D36644' }]}
            onPress={whatsappCustomer}
          >
            <MaterialCommunityIcons name="whatsapp" size={20} color="#25D366" />
            <Text style={[st.quickBtnLabel, { color: '#25D366' }]}>{t('whatsappAction')}</Text>
          </TouchableOpacity>
          {order.address ? (
            <TouchableOpacity
              style={[st.quickBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
              onPress={navigateToAddress}
            >
              <Feather name="navigation" size={20} color="#22c55e" />
              <Text style={[st.quickBtnLabel, { color: '#22c55e' }]}>{t('navigation')}</Text>
            </TouchableOpacity>
          ) : null}
        </View>

        {/* Customer info */}
        <InfoSection title={t('customerInfo')} colors={colors}>
          <InfoRow label={t('name')} value={order.customer_name} colors={colors} />
          <InfoRow label={t('phoneLabel')} value={order.phone || '—'} colors={colors} />
          {order.address ? (
            <InfoRow label={t('address')} value={order.address} colors={colors} last />
          ) : (
            <InfoRow label={t('address')} value={t('addressNotSet')} colors={colors} last muted />
          )}
        </InfoSection>

        {/* Order info */}
        <InfoSection title={t('orderDetails')} colors={colors}>
          <InfoRow label={t('service')} value={language === 'ar' ? service?.name_ar ?? '—' : service?.name_en || service?.name_ar || '—'} colors={colors} />
          <InfoRow
            label={t('zone')}
            value={zone ? (language === 'ar'
              ? `${zone.zone_name_ar}${zone.zone_name_en ? ' — ' + zone.zone_name_en : ''}`
              : zone.zone_name_en || zone.zone_name_ar) : '—'}
            colors={colors}
          />
          {Object.entries(order.submitted_custom_fields).map(([fieldId, val]) => {
            if (!val) return null;
            const field = service?.custom_fields.find(f => f.id === fieldId);
            return (
              <InfoRow
                key={fieldId}
                label={language === 'ar' ? field?.label_ar ?? fieldId : field?.label_en || field?.label_ar || fieldId}
                value={val}
                colors={colors}
              />
            );
          })}
          {order.notes ? (
            <InfoRow label={t('notes')} value={order.notes} colors={colors} last />
          ) : null}
        </InfoSection>

        {/* Pricing */}
        <InfoSection title={t('pricing')} colors={colors}>
          <InfoRow label={t('itemPriceLabel')} value={`$${order.item_price_usd.toFixed(2)}`} colors={colors} />
          <InfoRow label={t('deliveryFeeLabel')} value={`$${order.delivery_fee_usd.toFixed(2)}`} colors={colors} last={false} />
          <View style={[st.totalRow, { borderTopColor: colors.border }]}>
            <Text style={[st.totalLabel, { color: colors.foreground }]}>{t('totalLabel')}</Text>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={[st.totalUsd, { color: colors.accent }]}>${order.total_usd.toFixed(2)}</Text>
              <Text style={[st.totalLbp, { color: colors.mutedForeground }]}>
                {order.total_lbp.toLocaleString()} ل.ل.
              </Text>
            </View>
          </View>
        </InfoSection>
      </ScrollView>

      {/* Footer actions */}
      {canAct && (
        <View style={[st.footer, { paddingBottom: botPad + 8, backgroundColor: colors.background, borderTopColor: colors.border }]}>
          <TouchableOpacity
            style={[st.cancelOrderBtn, { borderColor: colors.destructive }]}
            onPress={cancelOrder}
          >
            <Feather name="x-circle" size={18} color={colors.destructive} />
            <Text style={[st.cancelOrderText, { color: colors.destructive }]}>{t('cancelOrder')}</Text>
          </TouchableOpacity>
          {nextStep && (
            <TouchableOpacity
              style={[st.advanceBtn, { backgroundColor: nextStep.color }]}
              onPress={advanceStatus}
              activeOpacity={0.85}
            >
              <Text style={st.advanceBtnText}>{t(nextStep.labelKey)}</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </View>
  );
}

function InfoSection({
  title, children, colors,
}: {
  title: string;
  children: React.ReactNode;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={[sectSt.title, { color: colors.mutedForeground }]}>{title}</Text>
      <View style={[sectSt.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {children}
      </View>
    </View>
  );
}

function InfoRow({
  label, value, colors, last = false, muted = false,
}: {
  label: string;
  value: string;
  colors: ReturnType<typeof useColors>;
  last?: boolean;
  muted?: boolean;
}) {
  return (
    <View style={[sectSt.row, !last && { borderBottomColor: colors.border, borderBottomWidth: 1 }]}>
      <Text style={[sectSt.label, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[sectSt.value, { color: muted ? colors.mutedForeground : colors.foreground }]} numberOfLines={2}>
        {value}
      </Text>
    </View>
  );
}

const sectSt = StyleSheet.create({
  title: {
    fontSize: 12, fontFamily: 'Inter_600SemiBold',
    textTransform: 'uppercase', letterSpacing: 0.8,
    marginBottom: 8, marginRight: 4,
  },
  card: { borderRadius: 14, borderWidth: 1, overflow: 'hidden', paddingHorizontal: 16 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, gap: 12 },
  label: { width: 110, fontSize: 13, fontFamily: 'Inter_400Regular' },
  value: { flex: 1, fontSize: 14, fontFamily: 'Inter_600SemiBold', textAlign: 'right' },
});

const st = StyleSheet.create({
  root: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 16, padding: 40 },
  notFoundText: { fontSize: 16, fontFamily: 'Inter_500Medium' },
  backBtn2: {
    borderRadius: 10, borderWidth: 1,
    paddingHorizontal: 20, paddingVertical: 10,
  },
  backBtn2Text: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingHorizontal: 16,
    paddingBottom: 14,
    borderBottomWidth: 1,
  },
  backCircle: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 17, fontFamily: 'Inter_700Bold' },
  scroll: { padding: 16, gap: 0 },
  statusBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    marginBottom: 14,
  },
  statusEmoji: { fontSize: 28 },
  statusLabel: { fontSize: 17, fontFamily: 'Inter_700Bold' },
  statusDate: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  orderId: { fontSize: 12, fontFamily: 'Inter_500Medium' },
  quickRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  quickBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    borderRadius: 12,
    borderWidth: 1,
    paddingVertical: 12,
  },
  quickBtnLabel: { fontSize: 14, fontFamily: 'Inter_700Bold' },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    borderTopWidth: 1,
    marginTop: 2,
  },
  totalLabel: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  totalUsd: { fontSize: 24, fontFamily: 'Inter_700Bold' },
  totalLbp: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  footer: {
    flexDirection: 'row',
    gap: 10,
    padding: 14,
    borderTopWidth: 1,
  },
  cancelOrderBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    borderRadius: 12, borderWidth: 1.5,
    paddingHorizontal: 16, paddingVertical: 14,
  },
  cancelOrderText: { fontSize: 14, fontFamily: 'Inter_700Bold' },
  advanceBtn: {
    flex: 1, borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center', justifyContent: 'center',
  },
  advanceBtnText: { color: '#fff', fontSize: 16, fontFamily: 'Inter_700Bold' },
});
