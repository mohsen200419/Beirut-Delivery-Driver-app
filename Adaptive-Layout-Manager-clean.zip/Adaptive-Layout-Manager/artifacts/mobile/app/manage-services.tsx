import React, { useState } from 'react';
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity,
  TextInput, Platform, Alert, Modal, Switch,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { KeyboardAwareScrollView } from 'react-native-keyboard-controller';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { Service, CustomField } from '@/types';
import { useLanguage } from '@/context/LanguageContext';

export default function ManageServicesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { services, addService, updateService, deleteService } = useApp();
  const { t, language } = useLanguage();

  const [showModal, setShowModal] = useState(false);
  const [editService, setEditService] = useState<Service | undefined>(undefined);

  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 34 : insets.bottom;

  const openAdd = () => { setEditService(undefined); setShowModal(true); };
  const openEdit = (s: Service) => { setEditService(s); setShowModal(true); };

  const handleSave = (data: Omit<Service, 'id' | 'is_active'>) => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    if (editService) {
      updateService({ ...editService, ...data });
    } else {
      const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
      addService({ id, is_active: true, ...data });
    }
    setShowModal(false);
  };

  const confirmDelete = (id: string) => {
    Alert.alert(t('delete'), language === 'ar' ? 'هل أنت متأكد؟' : language === 'fr' ? 'Êtes-vous sûr ?' : 'Are you sure?', [
      { text: t('cancel'), style: 'cancel' },
      { text: t('delete'), style: 'destructive', onPress: () => deleteService(id) },
    ]);
  };

  const renderItem = ({ item }: { item: Service }) => (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={styles.cardTop}>
        <View style={styles.cardLeft}>
          <Switch
            value={item.is_active}
            onValueChange={v => updateService({ ...item, is_active: v })}
            trackColor={{ false: colors.border, true: colors.primary + '66' }}
            thumbColor={item.is_active ? colors.primary : colors.mutedForeground}
          />
          <View>
            <Text style={[styles.svcName, { color: colors.foreground }]}>{language === 'ar' ? item.name_ar : item.name_en || item.name_ar}</Text>
            <Text style={[styles.svcNameEn, { color: colors.mutedForeground }]}>{language === 'ar' ? item.name_en : item.name_ar}</Text>
          </View>
        </View>
        <View style={styles.cardActions}>
          <TouchableOpacity onPress={() => openEdit(item)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Feather name="edit-2" size={16} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => confirmDelete(item.id)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Feather name="trash-2" size={16} color={colors.destructive} />
          </TouchableOpacity>
        </View>
      </View>
      {item.custom_fields.length > 0 && (
        <View style={[styles.fieldsRow, { borderTopColor: colors.border }]}>
          <Feather name="list" size={13} color={colors.mutedForeground} />
          <Text style={[styles.fieldsLabel, { color: colors.mutedForeground }]}>
            {item.custom_fields.length} {item.custom_fields.length === 1 ? t('field') : t('fields')}: {item.custom_fields.map(f => language === 'ar' ? f.label_ar : f.label_en || f.label_ar).join(language === 'fr' ? ', ' : ', ')}
          </Text>
        </View>
      )}
    </View>
  );

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 16, backgroundColor: colors.surface }]}>
        <TouchableOpacity onPress={() => router.back()} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Feather name="arrow-right" size={24} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>{t('services')}</Text>
        <TouchableOpacity
          style={[styles.addBtn, { backgroundColor: colors.primary }]}
          onPress={openAdd}
        >
          <Feather name="plus" size={18} color="#fff" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={services}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={[styles.list, { paddingBottom: botPad + 20 }]}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="package" size={32} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>{t('noServicesYet')}</Text>
          </View>
        }
        showsVerticalScrollIndicator={false}
      />

      <Modal visible={showModal} animationType="slide" presentationStyle="pageSheet">
        <ServiceForm
          initial={editService}
          onSave={handleSave}
          onCancel={() => setShowModal(false)}
          colors={colors}
        />
      </Modal>
    </View>
  );
}

function ServiceForm({
  initial, onSave, onCancel, colors,
}: {
  initial?: Service;
  onSave: (data: Omit<Service, 'id' | 'is_active'>) => void;
  onCancel: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  const { t, language } = useLanguage();
  const [nameAr, setNameAr] = useState(initial?.name_ar ?? '');
  const [nameEn, setNameEn] = useState(initial?.name_en ?? '');
  const [fields, setFields] = useState<CustomField[]>(initial?.custom_fields ?? []);
  const [newFieldLabel, setNewFieldLabel] = useState('');
  const [newFieldLabelEn, setNewFieldLabelEn] = useState('');
  const [newFieldRequired, setNewFieldRequired] = useState(false);

  const handleSave = () => {
    if (!nameAr.trim()) { Alert.alert(t('warning'), `${t('service')} — ${t('arabicName')}`); return; }
    onSave({ name_ar: nameAr.trim(), name_en: nameEn.trim(), custom_fields: fields });
  };

  const addField = () => {
    if (!newFieldLabel.trim()) { Alert.alert(t('warning'), t('fieldName')); return; }
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    setFields(prev => [...prev, {
      id,
      label_ar: newFieldLabel.trim(),
      label_en: newFieldLabelEn.trim() || newFieldLabel.trim(),
      type: 'text',
      required: newFieldRequired,
    }]);
    setNewFieldLabel('');
    setNewFieldLabelEn('');
    setNewFieldRequired(false);
  };

  const removeField = (id: string) => setFields(prev => prev.filter(f => f.id !== id));

  const insets = useSafeAreaInsets();
  const botPad = Platform.OS === 'web' ? 34 : insets.bottom;

  return (
    <View style={[formStyles.root, { backgroundColor: colors.background }]}>
      <View style={[formStyles.fHeader, { backgroundColor: colors.surface }]}>
        <TouchableOpacity onPress={onCancel}>
          <Feather name="x" size={24} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[formStyles.fTitle, { color: colors.foreground }]}>
          {initial ? t('editService') : t('newService')}
        </Text>
        <TouchableOpacity onPress={handleSave}>
          <Text style={[formStyles.fSave, { color: colors.primary }]}>{t('save')}</Text>
        </TouchableOpacity>
      </View>

      <KeyboardAwareScrollView
        contentContainerStyle={[formStyles.scroll, { paddingBottom: botPad + 20 }]}
        showsVerticalScrollIndicator={false}
        bottomOffset={20}
      >
        <View style={[formStyles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[formStyles.inputRow, { borderBottomColor: colors.border }]}>
            <Text style={[formStyles.inputLabel, { color: colors.mutedForeground }]}>{t('arabicName')} *</Text>
            <TextInput
              style={[formStyles.inputField, { color: colors.foreground }]}
              value={nameAr}
              onChangeText={setNameAr}
              placeholder="مثال: توصيل طعام"
              placeholderTextColor={colors.mutedForeground}
            />
          </View>
          <View style={[formStyles.inputRow, { borderBottomColor: 'transparent' }]}>
            <Text style={[formStyles.inputLabel, { color: colors.mutedForeground }]}>الاسم بالإنجليزية</Text>
            <TextInput
              style={[formStyles.inputField, { color: colors.foreground }]}
              value={nameEn}
              onChangeText={setNameEn}
              placeholder="e.g. Food Delivery"
              placeholderTextColor={colors.mutedForeground}
            />
          </View>
        </View>

            <Text style={[formStyles.sectionLabel, { color: colors.mutedForeground }]}>{t('extraFields')}</Text>
        {fields.map(field => (
          <View key={field.id} style={[formStyles.fieldChip, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
            <View>
              <Text style={[formStyles.chipLabel, { color: colors.foreground }]}>{language === 'ar' ? field.label_ar : field.label_en || field.label_ar}</Text>
              {field.required && (
                <Text style={[formStyles.chipRequired, { color: colors.accent }]}>{t('required')}</Text>
              )}
            </View>
            <TouchableOpacity onPress={() => removeField(field.id)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Feather name="x" size={16} color={colors.destructive} />
            </TouchableOpacity>
          </View>
        ))}

        <Text style={[formStyles.sectionLabel, { color: colors.mutedForeground }]}>{t('addNewField')}</Text>
        <View style={[formStyles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[formStyles.inputRow, { borderBottomColor: colors.border }]}>
            <Text style={[formStyles.inputLabel, { color: colors.mutedForeground }]}>{t('fieldName')}</Text>
            <TextInput
              style={[formStyles.inputField, { color: colors.foreground }]}
              value={newFieldLabel}
              onChangeText={setNewFieldLabel}
              placeholder="مثال: رقم التتبع"
              placeholderTextColor={colors.mutedForeground}
            />
          </View>
          <View style={[formStyles.inputRow, { borderBottomColor: colors.border }]}>
            <Text style={[formStyles.inputLabel, { color: colors.mutedForeground }]}>Field Name (EN)</Text>
            <TextInput
              style={[formStyles.inputField, { color: colors.foreground }]}
              value={newFieldLabelEn}
              onChangeText={setNewFieldLabelEn}
              placeholder="e.g. Tracking Number"
              placeholderTextColor={colors.mutedForeground}
            />
          </View>
          <View style={[formStyles.switchRow, { borderBottomColor: 'transparent' }]}>
            <Text style={[formStyles.inputLabel, { color: colors.mutedForeground }]}>{t('required')}</Text>
            <Switch
              value={newFieldRequired}
              onValueChange={setNewFieldRequired}
              trackColor={{ false: colors.border, true: colors.primary + '66' }}
              thumbColor={newFieldRequired ? colors.primary : colors.mutedForeground}
            />
          </View>
        </View>
        <TouchableOpacity
          style={[formStyles.addFieldBtn, { borderColor: colors.primary }]}
          onPress={addField}
        >
          <Feather name="plus" size={16} color={colors.primary} />
          <Text style={[formStyles.addFieldBtnText, { color: colors.primary }]}>{t('addField')}</Text>
        </TouchableOpacity>
      </KeyboardAwareScrollView>
    </View>
  );
}

const formStyles = StyleSheet.create({
  root: { flex: 1 },
  fHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 14,
  },
  fTitle: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  fSave: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  scroll: { padding: 20 },
  sectionLabel: {
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginTop: 20,
    marginBottom: 8,
  },
  section: { borderRadius: 14, borderWidth: 1, paddingHorizontal: 16, overflow: 'hidden' },
  inputRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, gap: 10 },
  switchRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, gap: 10 },
  inputLabel: { width: 110, fontSize: 13, fontFamily: 'Inter_500Medium' },
  inputField: { flex: 1, fontSize: 15, fontFamily: 'Inter_400Regular' },
  fieldChip: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginBottom: 8,
  },
  chipLabel: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  chipRequired: { fontSize: 11, fontFamily: 'Inter_400Regular', marginTop: 2 },
  addFieldBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    borderWidth: 1.5,
    borderStyle: 'dashed',
    paddingVertical: 14,
    gap: 8,
    marginTop: 12,
  },
  addFieldBtnText: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
});

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 14,
  },
  title: { fontSize: 20, fontFamily: 'Inter_700Bold' },
  addBtn: { width: 36, height: 36, borderRadius: 18, justifyContent: 'center', alignItems: 'center' },
  list: { padding: 16 },
  card: { borderRadius: 14, borderWidth: 1, padding: 14, marginBottom: 10 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardLeft: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  svcName: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  svcNameEn: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  cardActions: { flexDirection: 'row', gap: 14 },
  fieldsRow: { flexDirection: 'row', alignItems: 'center', gap: 6, borderTopWidth: 1, marginTop: 10, paddingTop: 10 },
  fieldsLabel: { fontSize: 12, fontFamily: 'Inter_400Regular', flex: 1 },
  empty: { alignItems: 'center', justifyContent: 'center', padding: 50, gap: 14 },
  emptyText: { fontSize: 15, fontFamily: 'Inter_500Medium' },
});
