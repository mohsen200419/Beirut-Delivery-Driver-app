import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  TextInput, Platform, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { useLanguage } from '@/context/LanguageContext';
import { AppLanguage } from '@/types';

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { settings, updateSettings, zones, services } = useApp();
  const { t, language, setLanguage } = useLanguage();

  const [ownerName, setOwnerName] = useState(settings.owner_name);
  const [whatsapp, setWhatsapp] = useState(settings.whatsapp_number);
  const [rate, setRate] = useState(String(settings.exchange_rate));
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    setOwnerName(settings.owner_name);
    setWhatsapp(settings.whatsapp_number);
    setRate(String(settings.exchange_rate));
    setDirty(false);
  }, [settings]);

  const markDirty = (setter: (v: string) => void) => (v: string) => {
    setter(v);
    setDirty(true);
  };

  const saveAll = () => {
    const rateNum = parseFloat(rate);
    if (isNaN(rateNum) || rateNum <= 0) {
      Alert.alert(t('error'), language === 'ar' ? 'سعر الصرف يجب أن يكون رقماً موجباً' : language === 'fr' ? 'Le taux doit être un nombre positif' : 'The exchange rate must be a positive number');
      return;
    }
    if (!ownerName.trim()) {
      Alert.alert(t('warning'), language === 'ar' ? 'أدخل اسمك' : language === 'fr' ? 'Saisissez votre nom' : 'Enter your name');
      return;
    }
    updateSettings({ owner_name: ownerName.trim(), whatsapp_number: whatsapp.trim(), exchange_rate: rateNum });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setDirty(false);
    Alert.alert(t('saved'), language === 'ar' ? 'تم حفظ إعداداتك بنجاح' : language === 'fr' ? 'Vos paramètres ont été enregistrés' : 'Your settings were saved');
  };

  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 84 : insets.bottom + 80;
  const rateNum = parseFloat(rate) || 0;
  const activeZones = zones.filter(z => z.is_active).length;
  const activeServices = services.filter(s => s.is_active).length;

  return (
    <View style={[st.root, { backgroundColor: colors.background }]}>
      <View style={[st.header, { paddingTop: topPad + 14, backgroundColor: colors.surface }]}>
        <Text style={[st.title, { color: colors.foreground }]}>{t('settings')}</Text>
        {dirty && (
          <TouchableOpacity
            style={[st.saveHeaderBtn, { backgroundColor: colors.primary }]}
            onPress={saveAll}
            activeOpacity={0.8}
          >
            <Text style={st.saveHeaderBtnText}>{t('saveShort')}</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView
        contentContainerStyle={[st.scroll, { paddingBottom: botPad }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Language section */}
        <SectionLabel label={t('language')} colors={colors} />
        <View style={[st.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[st.languageHint, { color: colors.mutedForeground }]}>{t('languageHint')}</Text>
          <View style={st.languageRow}>
            {([
              ['ar', 'العربية'],
              ['en', 'English'],
              ['fr', 'Français'],
            ] as [AppLanguage, string][]).map(([code, label]) => (
              <TouchableOpacity
                key={code}
                style={[
                  st.languageOption,
                  {
                    backgroundColor: language === code ? colors.primary : colors.secondary,
                    borderColor: language === code ? colors.primary : colors.border,
                  },
                ]}
                onPress={() => setLanguage(code)}
                activeOpacity={0.8}
              >
                <Text style={[st.languageOptionText, { color: language === code ? '#fff' : colors.foreground }]}>
                  {label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Profile section */}
        <SectionLabel label={t('profile')} colors={colors} />
        <View style={[st.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <FieldRow
            label={t('yourName')}
            icon="user"
            value={ownerName}
            onChangeText={markDirty(setOwnerName)}
            placeholder={t('ownerNamePlaceholder')}
            colors={colors}
          />
          <FieldRow
            label={t('whatsapp')}
            icon="message-circle"
            value={whatsapp}
            onChangeText={markDirty(setWhatsapp)}
            placeholder="+96170000000"
            keyboardType="phone-pad"
            colors={colors}
            last
          />
        </View>
        <Text style={[st.hint, { color: colors.mutedForeground }]}>
          {t('driverWhatsappHint')}
        </Text>

        {/* Financial section */}
        <SectionLabel label={t('finance')} colors={colors} />
        <View style={[st.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[st.fieldRow, { borderBottomColor: 'transparent' }]}>
            <View style={[st.fieldIcon, { backgroundColor: colors.accent + '22' }]}>
              <MaterialCommunityIcons name="currency-usd" size={18} color={colors.accent} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[st.fieldLabel, { color: colors.mutedForeground }]}>{t('dollarRate')}</Text>
              <TextInput
                style={[st.fieldInput, { color: colors.foreground }]}
                value={rate}
                onChangeText={markDirty(setRate)}
                placeholder="89500"
                keyboardType="numeric"
                placeholderTextColor={colors.mutedForeground}
              />
            </View>
            <Text style={[st.currSymbol, { color: colors.mutedForeground }]}>ل.ل.</Text>
          </View>
        </View>
        {rateNum > 0 && (
          <View style={[st.ratePreview, { backgroundColor: colors.secondary }]}>
            <Text style={[st.ratePreviewText, { color: colors.mutedForeground }]}>
              $1 = <Text style={{ color: colors.accent, fontFamily: 'Inter_700Bold' }}>{rateNum.toLocaleString()} ل.ل.</Text>
              {'  '}|{'  '}
              $5 = <Text style={{ color: colors.accent, fontFamily: 'Inter_700Bold' }}>{(rateNum * 5).toLocaleString()} ل.ل.</Text>
              {'  '}|{'  '}
              $10 = <Text style={{ color: colors.accent, fontFamily: 'Inter_700Bold' }}>{(rateNum * 10).toLocaleString()} ل.ل.</Text>
            </Text>
          </View>
        )}

        {/* Save button */}
        <TouchableOpacity
          style={[st.saveBtn, { backgroundColor: dirty ? colors.primary : colors.secondary }]}
          onPress={saveAll}
          activeOpacity={0.8}
        >
          <Feather name="save" size={18} color={dirty ? '#fff' : colors.mutedForeground} />
            <Text style={[st.saveBtnText, { color: dirty ? '#fff' : colors.mutedForeground }]}>
            {dirty ? t('saveChanges') : t('saved')}
          </Text>
        </TouchableOpacity>

        {/* Management links */}
        <SectionLabel label={t('management')} colors={colors} />

        <NavCard
          icon="map-pin"
          iconColor={colors.primary}
          label={t('zones')}
          sub={activeZones > 0
            ? `${activeZones} ${t('zoneCount')} ${t('active')}`
            : `⚠️ ${t('noZones')}`}
          subColor={activeZones === 0 ? '#f59e0b' : colors.mutedForeground}
          onPress={() => router.push('/manage-zones')}
          colors={colors}
          urgent={activeZones === 0}
        />
        <NavCard
          icon="package"
          iconColor={colors.primary}
          label={t('services')}
           sub={`${activeServices} ${activeServices === 1 ? t('activeService') : t('activeServices')}`}
          onPress={() => router.push('/manage-services')}
          colors={colors}
        />

        {/* App info */}
        <SectionLabel label={t('about')} colors={colors} />
        <View style={[st.aboutCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={st.aboutRow}>
            <Feather name="smartphone" size={16} color={colors.mutedForeground} />
            <Text style={[st.aboutText, { color: colors.mutedForeground }]}>Beirut Delivery — {t('aboutDescription')}</Text>
          </View>
          <View style={st.aboutRow}>
            <Feather name="database" size={16} color={colors.mutedForeground} />
            <Text style={[st.aboutText, { color: colors.mutedForeground }]}>
              {zones.length} {t('zoneCount')} · {services.length} {t('services')}
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function SectionLabel({ label, colors }: { label: string; colors: ReturnType<typeof useColors> }) {
  return (
    <Text style={[sectSt.label, { color: colors.mutedForeground }]}>{label}</Text>
  );
}

function FieldRow({
  label, icon, value, onChangeText, placeholder, keyboardType = 'default', colors, last = false,
}: {
  label: string;
  icon: string;
  value: string;
  onChangeText: (v: string) => void;
  placeholder?: string;
  keyboardType?: 'default' | 'numeric' | 'phone-pad';
  colors: ReturnType<typeof useColors>;
  last?: boolean;
}) {
  return (
    <View style={[st.fieldRow, { borderBottomColor: last ? 'transparent' : colors.border }]}>
      <View style={[st.fieldIcon, { backgroundColor: colors.secondary }]}>
        <Feather name={icon as any} size={18} color={colors.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[st.fieldLabel, { color: colors.mutedForeground }]}>{label}</Text>
        <TextInput
          style={[st.fieldInput, { color: colors.foreground }]}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={colors.mutedForeground}
          keyboardType={keyboardType}
        />
      </View>
    </View>
  );
}

function NavCard({
  icon, iconColor, label, sub, subColor, onPress, colors, urgent = false,
}: {
  icon: string;
  iconColor: string;
  label: string;
  sub: string;
  subColor?: string;
  onPress: () => void;
  colors: ReturnType<typeof useColors>;
  urgent?: boolean;
}) {
  return (
    <TouchableOpacity
      style={[st.navCard, {
        backgroundColor: colors.card,
        borderColor: urgent ? '#f59e0b44' : colors.border,
        borderWidth: urgent ? 1.5 : 1,
      }]}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <View style={[st.navIcon, { backgroundColor: iconColor + '22' }]}>
        <Feather name={icon as any} size={22} color={iconColor} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[st.navLabel, { color: colors.foreground }]}>{label}</Text>
        <Text style={[st.navSub, { color: subColor ?? colors.mutedForeground }]}>{sub}</Text>
      </View>
      <Feather name="chevron-left" size={18} color={colors.mutedForeground} />
    </TouchableOpacity>
  );
}

const sectSt = StyleSheet.create({
  label: {
    fontSize: 12, fontFamily: 'Inter_600SemiBold',
    textTransform: 'uppercase', letterSpacing: 0.8,
    marginTop: 24, marginBottom: 10, marginRight: 4,
  },
});

const st = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingHorizontal: 20,
    paddingBottom: 14,
  },
  title: { fontSize: 26, fontFamily: 'Inter_700Bold' },
  saveHeaderBtn: {
    paddingHorizontal: 20, paddingVertical: 8, borderRadius: 20,
  },
  saveHeaderBtnText: { color: '#fff', fontSize: 15, fontFamily: 'Inter_700Bold' },
  scroll: { paddingHorizontal: 16, paddingTop: 8 },
  card: { borderRadius: 14, borderWidth: 1, overflow: 'hidden' },
  fieldRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderBottomWidth: 1,
    gap: 12,
  },
  fieldIcon: { width: 38, height: 38, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  fieldLabel: { fontSize: 11, fontFamily: 'Inter_500Medium', marginBottom: 2 },
  fieldInput: { fontSize: 16, fontFamily: 'Inter_400Regular', paddingVertical: 0 },
  languageHint: { fontSize: 13, fontFamily: 'Inter_400Regular', padding: 14, paddingBottom: 4 },
  languageRow: { flexDirection: 'row', gap: 8, padding: 14 },
  languageOption: { flex: 1, borderRadius: 10, borderWidth: 1, paddingVertical: 12, alignItems: 'center' },
  languageOptionText: { fontSize: 13, fontFamily: 'Inter_700Bold' },
  currSymbol: { fontSize: 16, fontFamily: 'Inter_600SemiBold', marginRight: 4 },
  hint: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 6, marginRight: 4 },
  ratePreview: { borderRadius: 10, padding: 10, marginTop: 8, alignItems: 'center' },
  ratePreviewText: { fontSize: 13, fontFamily: 'Inter_400Regular', textAlign: 'center' },
  saveBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, borderRadius: 14, paddingVertical: 16, marginTop: 16,
  },
  saveBtnText: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  navCard: {
    flexDirection: 'row', alignItems: 'center',
    borderRadius: 14, padding: 14, marginBottom: 10, gap: 12,
  },
  navIcon: { width: 46, height: 46, borderRadius: 23, justifyContent: 'center', alignItems: 'center' },
  navLabel: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  navSub: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  aboutCard: { borderRadius: 14, borderWidth: 1, padding: 14, gap: 10 },
  aboutRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  aboutText: { fontSize: 13, fontFamily: 'Inter_400Regular' },
});
