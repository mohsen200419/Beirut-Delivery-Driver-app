import React, { useMemo, useState } from 'react';
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity, Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { useLanguage } from '@/context/LanguageContext';
import { OrderCard } from '@/components/OrderCard';
import { Order, OrderStatus } from '@/types';

type Filter = 'all' | 'active' | 'delivered' | 'cancelled';

const FILTER_KEYS: { key: Filter; translation: string }[] = [
  { key: 'all',       translation: 'all' },
  { key: 'active',    translation: 'activeFilter' },
  { key: 'delivered', translation: 'deliveredFilter' },
  { key: 'cancelled', translation: 'cancelled' },
];

const ACTIVE_STATUSES: OrderStatus[] = ['pending', 'accepted', 'in_delivery'];

export default function OrdersScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { orders, zones, services, isSetupComplete, updateOrderStatus, deleteOrder } = useApp();
  const { t, language } = useLanguage();
  const [filter, setFilter] = useState<Filter>('all');

  const filtered = useMemo(() => {
    switch (filter) {
      case 'active':    return orders.filter(o => ACTIVE_STATUSES.includes(o.status));
      case 'delivered': return orders.filter(o => o.status === 'delivered');
      case 'cancelled': return orders.filter(o => o.status === 'cancelled');
      default:          return orders;
    }
  }, [orders, filter]);

  const counts = useMemo(() => ({
    all: orders.length,
    active: orders.filter(o => ACTIVE_STATUSES.includes(o.status)).length,
    delivered: orders.filter(o => o.status === 'delivered').length,
    cancelled: orders.filter(o => o.status === 'cancelled').length,
  }), [orders]);

  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 84 : insets.bottom + 80;

  const renderItem = ({ item }: { item: Order }) => {
    const zone = zones.find(z => z.id === item.zone_id);
    const service = services.find(s => s.id === item.service_id);
    return (
      <OrderCard
        order={item}
        zoneName={language === 'ar' ? zone?.zone_name_ar ?? '—' : zone?.zone_name_en || zone?.zone_name_ar || '—'}
        serviceName={language === 'ar' ? service?.name_ar ?? '—' : service?.name_en || service?.name_ar || '—'}
        onStatusChange={updateOrderStatus}
        onDelete={deleteOrder}
      />
    );
  };

  return (
    <View style={[st.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[st.header, { paddingTop: topPad + 14, backgroundColor: colors.surface }]}>
        <View>
          <Text style={[st.title, { color: colors.foreground }]}>{t('orders')}</Text>
          <Text style={[st.subtitle, { color: colors.mutedForeground }]}>{counts.all} {t('orderCount')}</Text>
        </View>
        {isSetupComplete && (
          <TouchableOpacity
            style={[st.addBtn, { backgroundColor: colors.primary }]}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              router.push('/add-order');
            }}
            activeOpacity={0.8}
          >
            <Feather name="plus" size={20} color="#fff" />
            <Text style={st.addBtnText}>{t('newOrder')}</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Filter pills */}
      <View style={[st.filterRow, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        {FILTER_KEYS.map(f => {
          const active = filter === f.key;
          const count = counts[f.key];
          return (
            <TouchableOpacity
              key={f.key}
              style={[
                st.filterPill,
                active
                  ? { backgroundColor: colors.primary }
                  : { backgroundColor: colors.secondary },
              ]}
              onPress={() => setFilter(f.key)}
              activeOpacity={0.8}
            >
              <Text style={[st.filterLabel, { color: active ? '#fff' : colors.mutedForeground }]}>
                {t(f.translation)}
              </Text>
              {count > 0 && (
                <View style={[st.filterBadge, { backgroundColor: active ? 'rgba(255,255,255,0.3)' : colors.primary + '22' }]}>
                  <Text style={[st.filterBadgeText, { color: active ? '#fff' : colors.primary }]}>
                    {count}
                  </Text>
                </View>
              )}
            </TouchableOpacity>
          );
        })}
      </View>

      {/* No setup state */}
      {!isSetupComplete ? (
        <View style={[st.emptyFull, { backgroundColor: colors.background }]}>
          <MaterialCommunityIcons name="map-marker-off" size={52} color={colors.mutedForeground} />
          <Text style={[st.emptyTitle, { color: colors.foreground }]}>{t('addZonesFirst')}</Text>
          <Text style={[st.emptyDesc, { color: colors.mutedForeground }]}>
            {t('addZoneBeforeOrders')}
          </Text>
          <TouchableOpacity
            style={[st.emptyBtn, { backgroundColor: colors.primary }]}
            onPress={() => router.push('/manage-zones')}
          >
            <Feather name="map-pin" size={16} color="#fff" />
            <Text style={st.emptyBtnText}>{t('setupZones')}</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          contentContainerStyle={[st.list, { paddingBottom: botPad }]}
          ListEmptyComponent={
            <View style={[st.empty, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <MaterialCommunityIcons name="package-variant" size={44} color={colors.mutedForeground} />
              <Text style={[st.emptyTitle, { color: colors.foreground }]}>
                {filter === 'all' ? t('noOrders') : `${t('noFilteredOrders')} ${t(FILTER_KEYS.find(f => f.key === filter)?.translation ?? 'orders')}`}
              </Text>
              {filter === 'all' && (
                <TouchableOpacity
                  style={[st.emptyBtn, { backgroundColor: colors.primary }]}
                  onPress={() => router.push('/add-order')}
                >
                  <Feather name="plus" size={16} color="#fff" />
                  <Text style={st.emptyBtnText}>{t('addOrderNow')}</Text>
                </TouchableOpacity>
              )}
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const st = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingHorizontal: 20,
    paddingBottom: 14,
  },
  title: { fontSize: 24, fontFamily: 'Inter_700Bold' },
  subtitle: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  addBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20,
  },
  addBtnText: { color: '#fff', fontSize: 14, fontFamily: 'Inter_700Bold' },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  filterPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 20,
  },
  filterLabel: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  filterBadge: { borderRadius: 10, paddingHorizontal: 6, paddingVertical: 1 },
  filterBadgeText: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  list: { padding: 14 },
  emptyFull: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    gap: 14,
  },
  empty: {
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
    padding: 48,
    gap: 12,
    marginTop: 10,
  },
  emptyTitle: { fontSize: 18, fontFamily: 'Inter_700Bold', textAlign: 'center' },
  emptyDesc: { fontSize: 13, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 20 },
  emptyBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12, marginTop: 6,
  },
  emptyBtnText: { color: '#fff', fontSize: 15, fontFamily: 'Inter_700Bold' },
});
