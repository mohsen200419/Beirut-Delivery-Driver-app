import React, { useMemo, useState } from 'react';
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity, Platform, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { useLanguage } from '@/context/LanguageContext';
import { StatCard } from '@/components/StatCard';
import { Expense, ExpenseType } from '@/types';

const EXPENSE_ICONS: Record<ExpenseType, string> = {
  fuel: 'gas-station',
  maintenance: 'wrench',
  other: 'cash',
};

const EXPENSE_LABELS: Record<ExpenseType, string> = {
  fuel: 'بنزين',
  maintenance: 'صيانة',
  other: 'أخرى',
};

type Tab = 'income' | 'expenses';

export default function LedgerScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { orders, expenses, settings, deleteExpense } = useApp();
  const { t, language } = useLanguage();
  const [tab, setTab] = useState<Tab>('income');

  const today = useMemo(() => new Date().toDateString(), []);

  const financials = useMemo(() => {
    const allDelivered = orders.filter(o => o.status === 'delivered');
    const todayDelivered = allDelivered.filter(o => new Date(o.created_at).toDateString() === today);

    const totalRevenue = allDelivered.reduce((s, o) => s + o.delivery_fee_usd, 0);
    const todayRevenue = todayDelivered.reduce((s, o) => s + o.delivery_fee_usd, 0);
    const totalExpenses = expenses.reduce((s, e) => s + e.amount_usd, 0);
    const todayExpenses = expenses
      .filter(e => new Date(e.date).toDateString() === today)
      .reduce((s, e) => s + e.amount_usd, 0);

    return { totalRevenue, todayRevenue, totalExpenses, todayExpenses, net: totalRevenue - totalExpenses };
  }, [orders, expenses, today]);

  const incomeItems = useMemo(
    () => orders.filter(o => o.status === 'delivered').map(o => ({
      id: o.id,
      label: o.customer_name,
      amount: o.delivery_fee_usd,
      amountLbp: Math.round(o.delivery_fee_usd * settings.exchange_rate),
      date: o.created_at,
      sub: 'رسوم توصيل',
    })),
    [orders, settings.exchange_rate],
  );

  const topPadding = Platform.OS === 'web' ? 67 : insets.top;

  const renderExpense = ({ item }: { item: Expense }) => (
    <View style={[styles.txRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.txIcon, { backgroundColor: colors.surface }]}>
        <MaterialCommunityIcons
          name={EXPENSE_ICONS[item.type] as any}
          size={20}
          color={colors.destructive}
        />
      </View>
      <View style={styles.txInfo}>
        <Text style={[styles.txLabel, { color: colors.foreground }]}>{EXPENSE_LABELS[item.type]}</Text>
        {item.notes ? <Text style={[styles.txSub, { color: colors.mutedForeground }]}>{item.notes}</Text> : null}
        <Text style={[styles.txDate, { color: colors.mutedForeground }]}>
          {new Date(item.date).toLocaleDateString('ar-LB')}
        </Text>
      </View>
      <View style={styles.txRight}>
        <Text style={[styles.txAmount, { color: colors.destructive }]}>-${item.amount_usd.toFixed(2)}</Text>
        <Text style={[styles.txAmountSub, { color: colors.mutedForeground }]}>
          {item.amount_lbp.toLocaleString()} ل.ل.
        </Text>
        <TouchableOpacity
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          onPress={() => {
            Alert.alert(t('deleteExpense'), language === 'ar' ? 'حذف هذا المصروف؟' : language === 'fr' ? 'Supprimer cette dépense ?' : 'Delete this expense?', [
              { text: t('cancel'), style: 'cancel' },
              { text: t('delete'), style: 'destructive', onPress: () => deleteExpense(item.id) },
            ]);
          }}
        >
          <Feather name="trash-2" size={14} color={colors.mutedForeground} />
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderIncome = ({ item }: { item: typeof incomeItems[number] }) => (
    <View style={[styles.txRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.txIcon, { backgroundColor: colors.surface }]}>
        <MaterialCommunityIcons name="package-variant-closed" size={20} color={colors.success} />
      </View>
      <View style={styles.txInfo}>
        <Text style={[styles.txLabel, { color: colors.foreground }]}>{item.label}</Text>
        <Text style={[styles.txSub, { color: colors.mutedForeground }]}>{item.sub}</Text>
        <Text style={[styles.txDate, { color: colors.mutedForeground }]}>
          {new Date(item.date).toLocaleDateString('ar-LB')}
        </Text>
      </View>
      <View style={styles.txRight}>
        <Text style={[styles.txAmount, { color: colors.success }]}>+${item.amount.toFixed(2)}</Text>
        <Text style={[styles.txAmountSub, { color: colors.mutedForeground }]}>
          {item.amountLbp.toLocaleString()} ل.ل.
        </Text>
      </View>
    </View>
  );

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPadding + 16, backgroundColor: colors.surface }]}>
       <Text style={[styles.title, { color: colors.foreground }]}>{t('ledger')}</Text>
        <TouchableOpacity
          style={[styles.addBtn, { backgroundColor: colors.primary }]}
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            router.push('/add-expense');
          }}
        >
          <Feather name="plus" size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Exchange rate banner */}
      <View style={[styles.rateBanner, { backgroundColor: colors.secondary }]}>
        <MaterialCommunityIcons name="currency-usd" size={14} color={colors.accent} />
        <Text style={[styles.rateText, { color: colors.mutedForeground }]}>
          {t('exchangeRate')}: {'  '}
          <Text style={{ color: colors.accent, fontFamily: 'Inter_700Bold' }}>
            {settings.exchange_rate.toLocaleString()} ل.ل. / {t('perDollar')}
          </Text>
        </Text>
      </View>

      {/* Summary cards */}
      <View style={styles.statsRow}>
        <StatCard
          label={t('totalRevenue')}
          value={`$${financials.totalRevenue.toFixed(2)}`}
          subtitle={`${language === 'ar' ? 'اليوم' : language === 'fr' ? "Aujourd'hui" : 'Today'}: $${financials.todayRevenue.toFixed(2)}`}
          accentColor={colors.success}
        />
        <StatCard
          label={t('totalExpenses')}
          value={`$${financials.totalExpenses.toFixed(2)}`}
          subtitle={`${language === 'ar' ? 'اليوم' : language === 'fr' ? "Aujourd'hui" : 'Today'}: $${financials.todayExpenses.toFixed(2)}`}
          accentColor={colors.destructive}
        />
      </View>
      <View style={styles.netRow}>
        <StatCard
          label={t('totalNet')}
          value={`$${financials.net.toFixed(2)}`}
          subtitle={`${Math.round(financials.net * settings.exchange_rate).toLocaleString()} ل.ل.`}
          accentColor={financials.net >= 0 ? colors.success : colors.destructive}
        />
      </View>

      {/* Tab toggle */}
      <View style={[styles.tabRow, { borderColor: colors.border }]}>
        {(['income', 'expenses'] as Tab[]).map(tabKey => (
          <TouchableOpacity
            key={tabKey}
            style={[styles.tabBtn, tab === tabKey && { backgroundColor: colors.primary }]}
            onPress={() => setTab(tabKey)}
          >
            <Text style={[styles.tabLabel, { color: tab === tabKey ? '#fff' : colors.mutedForeground }]}>
              {tabKey === 'income' ? t('income') : t('expenses')}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {tab === 'expenses' ? (
        <FlatList
          data={expenses}
          keyExtractor={item => item.id}
          renderItem={renderExpense}
          contentContainerStyle={[
            styles.list,
            { paddingBottom: Platform.OS === 'web' ? 100 : insets.bottom + 90 },
          ]}
          ListEmptyComponent={
            <View style={styles.emptyBox}>
              <Feather name="file-text" size={32} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>{t('noExpenses')}</Text>
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <FlatList
          data={incomeItems}
          keyExtractor={item => item.id}
          renderItem={renderIncome}
          contentContainerStyle={[
            styles.list,
            { paddingBottom: Platform.OS === 'web' ? 100 : insets.bottom + 90 },
          ]}
          ListEmptyComponent={
            <View style={styles.emptyBox}>
              <Feather name="trending-up" size={32} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>{t('noIncome')}</Text>
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingHorizontal: 20,
    paddingBottom: 14,
  },
  title: { fontSize: 24, fontFamily: 'Inter_700Bold' },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rateBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  rateText: { fontSize: 13, fontFamily: 'Inter_400Regular' },
  statsRow: { flexDirection: 'row', gap: 10, paddingHorizontal: 16, paddingTop: 14 },
  netRow: { paddingHorizontal: 16, paddingTop: 10, paddingBottom: 4 },
  tabRow: {
    flexDirection: 'row',
    margin: 16,
    borderRadius: 10,
    borderWidth: 1,
    overflow: 'hidden',
  },
  tabBtn: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  tabLabel: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  list: { paddingHorizontal: 16 },
  txRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 1,
    padding: 12,
    marginBottom: 8,
    gap: 12,
  },
  txIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    justifyContent: 'center',
    alignItems: 'center',
  },
  txInfo: { flex: 1 },
  txLabel: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  txSub: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  txDate: { fontSize: 11, fontFamily: 'Inter_400Regular', marginTop: 2 },
  txRight: { alignItems: 'flex-end', gap: 4 },
  txAmount: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  txAmountSub: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  emptyBox: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 50,
    gap: 14,
  },
  emptyText: { fontSize: 15, fontFamily: 'Inter_500Medium' },
});
