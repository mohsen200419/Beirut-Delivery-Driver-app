import React, { useMemo } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity, Platform, ActivityIndicator,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { useLanguage } from '@/context/LanguageContext';
import { StatCard } from '@/components/StatCard';
import { OrderCard } from '@/components/OrderCard';

const DAYS_AR = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const MONTHS_AR = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

function formatDateAr(d: Date, language: 'ar' | 'en' | 'fr') {
  if (language === 'en') return d.toLocaleDateString('en-LB', { dateStyle: 'full' });
  if (language === 'fr') return d.toLocaleDateString('fr-LB', { dateStyle: 'full' });
  return `${DAYS_AR[d.getDay()]}، ${d.getDate()} ${MONTHS_AR[d.getMonth()]} ${d.getFullYear()}`;
}

export default function DashboardScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { orders, expenses, settings, zones, services, isLoading, isSetupComplete, updateOrderStatus, deleteOrder } = useApp();
  const { t, language } = useLanguage();

  const today = useMemo(() => new Date().toDateString(), []);

  const stats = useMemo(() => {
    const active = orders.filter(o => ['pending', 'accepted', 'in_delivery'].includes(o.status));
    const todayDelivered = orders.filter(
      o => o.status === 'delivered' && new Date(o.created_at).toDateString() === today,
    );
    const todayRevenue = todayDelivered.reduce((s, o) => s + o.delivery_fee_usd, 0);
    const todayExpenses = expenses
      .filter(e => new Date(e.date).toDateString() === today)
      .reduce((s, e) => s + e.amount_usd, 0);
    const net = todayRevenue - todayExpenses;
    return {
      active: active.length,
      todayDelivered: todayDelivered.length,
      todayRevenue,
      todayExpenses,
      net,
    };
  }, [orders, expenses, today]);

  const recentOrders = useMemo(() => orders.slice(0, 6), [orders]);

  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 84 : insets.bottom + 80;

  if (isLoading) {
    return (
      <View style={[st.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} size="large" />
      </View>
    );
  }

  return (
    <View style={[st.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[st.header, { paddingTop: topPad + 14, backgroundColor: colors.surface }]}>
        <View>
          <Text style={[st.greeting, { color: colors.mutedForeground }]}>{t('hello')} 👋</Text>
          <Text style={[st.ownerName, { color: colors.foreground }]}>{settings.owner_name}</Text>
          <Text style={[st.dateStr, { color: colors.mutedForeground }]}>{formatDateAr(new Date(), language)}</Text>
        </View>
        {isSetupComplete && (
          <TouchableOpacity
            style={[st.fabHeader, { backgroundColor: colors.primary }]}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              router.push('/add-order');
            }}
            activeOpacity={0.8}
          >
            <Feather name="plus" size={22} color="#fff" />
          </TouchableOpacity>
        )}
      </View>

      <ScrollView
        contentContainerStyle={[st.scroll, { paddingBottom: botPad }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Setup prompt — shown when no zones exist */}
        {!isSetupComplete && (
          <View style={[st.setupCard, { backgroundColor: colors.primary + '18', borderColor: colors.primary + '44' }]}>
            <MaterialCommunityIcons name="rocket-launch-outline" size={32} color={colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={[st.setupTitle, { color: colors.foreground }]}>{t('setupApp')}</Text>
              <Text style={[st.setupDesc, { color: colors.mutedForeground }]}>
                {t('setupDescription')}
              </Text>
            </View>
            <TouchableOpacity
              style={[st.setupBtn, { backgroundColor: colors.primary }]}
              onPress={() => router.push('/manage-zones')}
              activeOpacity={0.8}
            >
              <Text style={st.setupBtnText}>{t('setupZones')}</Text>
              <Feather name="arrow-left" size={16} color="#fff" />
            </TouchableOpacity>
          </View>
        )}

        {/* Stats */}
        {isSetupComplete && (
          <>
            <Text style={[st.section, { color: colors.foreground }]}>{t('todayStats')}</Text>
            <View style={st.statsGrid}>
              <StatCard label={t('activeOrders')} value={String(stats.active)} accentColor={colors.primary} />
              <StatCard label={t('delivered')} value={String(stats.todayDelivered)} accentColor={colors.success} />
            </View>
            <View style={st.statsGrid}>
              <StatCard
                label={t('deliveryRevenue')}
                value={`$${stats.todayRevenue.toFixed(2)}`}
                subtitle={`${Math.round(stats.todayRevenue * settings.exchange_rate / 1000).toLocaleString()}K ل.ل.`}
                accentColor={colors.accent}
              />
              <StatCard
                label={t('netProfit')}
                value={`$${stats.net.toFixed(2)}`}
                subtitle={stats.net >= 0 ? t('afterExpenses') : (language === 'ar' ? 'خسارة' : language === 'fr' ? 'Perte' : 'Loss')}
                accentColor={stats.net >= 0 ? colors.success : colors.destructive}
              />
            </View>
          </>
        )}

        {/* Whatsapp not set warning */}
        {isSetupComplete && !settings.whatsapp_number && (
          <TouchableOpacity
            style={[st.warnCard, { backgroundColor: '#f59e0b18', borderColor: '#f59e0b44' }]}
            onPress={() => router.push('/(tabs)/settings')}
            activeOpacity={0.8}
          >
            <Feather name="alert-triangle" size={18} color="#f59e0b" />
            <Text style={[st.warnText, { color: '#f59e0b' }]}>
              {language === 'ar'
                ? 'أضف رقم واتساب من الإعدادات لإرسال رسائل للعملاء'
                : language === 'fr'
                  ? 'Ajoutez votre WhatsApp dans les paramètres pour contacter les clients'
                  : 'Add your WhatsApp number in Settings to contact customers'}
            </Text>
            <Feather name="chevron-left" size={16} color="#f59e0b" />
          </TouchableOpacity>
        )}

        {/* Recent orders */}
        {isSetupComplete && (
          <>
            <View style={st.sectionRow}>
              <Text style={[st.section, { color: colors.foreground }]}>{t('recentOrders')}</Text>
              {orders.length > 0 && (
                <TouchableOpacity onPress={() => router.push('/(tabs)/orders')}>
                  <Text style={[st.seeAll, { color: colors.primary }]}>{t('seeAll')}</Text>
                </TouchableOpacity>
              )}
            </View>

            {recentOrders.length === 0 ? (
              <View style={[st.empty, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <MaterialCommunityIcons name="package-variant" size={40} color={colors.mutedForeground} />
                <Text style={[st.emptyTitle, { color: colors.foreground }]}>{t('noOrders')}</Text>
                <Text style={[st.emptyDesc, { color: colors.mutedForeground }]}>
                  {language === 'ar'
                    ? 'اضغط على + لإضافة أول طلب توصيل'
                    : language === 'fr'
                      ? 'Appuyez sur + pour ajouter votre première livraison'
                      : 'Tap + to add your first delivery'}
                </Text>
                <TouchableOpacity
                  style={[st.emptyBtn, { backgroundColor: colors.primary }]}
                  onPress={() => router.push('/add-order')}
                  activeOpacity={0.8}
                >
                  <Feather name="plus" size={16} color="#fff" />
                  <Text style={st.emptyBtnText}>{t('newOrder')}</Text>
                </TouchableOpacity>
              </View>
            ) : (
              recentOrders.map(order => {
                const zone = zones.find(z => z.id === order.zone_id);
                const service = services.find(s => s.id === order.service_id);
                return (
                  <OrderCard
                    key={order.id}
                    order={order}
                    zoneName={language === 'ar' ? zone?.zone_name_ar ?? '—' : zone?.zone_name_en || zone?.zone_name_ar || '—'}
                    serviceName={language === 'ar' ? service?.name_ar ?? '—' : service?.name_en || service?.name_ar || '—'}
                    onStatusChange={updateOrderStatus}
                    onDelete={deleteOrder}
                  />
                );
              })
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
}

const st = StyleSheet.create({
  root: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  greeting: { fontSize: 13, fontFamily: 'Inter_400Regular' },
  ownerName: { fontSize: 24, fontFamily: 'Inter_700Bold', marginTop: 2 },
  dateStr: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  fabHeader: { width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' },
  scroll: { padding: 16, gap: 0 },
  setupCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    flexWrap: 'wrap',
    marginBottom: 16,
  },
  setupTitle: { fontSize: 16, fontFamily: 'Inter_700Bold', marginBottom: 4 },
  setupDesc: { fontSize: 13, fontFamily: 'Inter_400Regular', lineHeight: 20 },
  setupBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 16, paddingVertical: 10, borderRadius: 10, marginTop: 8,
  },
  setupBtnText: { color: '#fff', fontSize: 14, fontFamily: 'Inter_700Bold' },
  warnCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderRadius: 12,
    borderWidth: 1,
    padding: 12,
    marginBottom: 12,
  },
  warnText: { flex: 1, fontSize: 13, fontFamily: 'Inter_500Medium' },
  section: { fontSize: 18, fontFamily: 'Inter_700Bold', marginBottom: 12, marginTop: 8 },
  statsGrid: { flexDirection: 'row', gap: 10, marginBottom: 10 },
  sectionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  seeAll: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  empty: {
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
    padding: 36,
    gap: 10,
    marginTop: 4,
  },
  emptyTitle: { fontSize: 17, fontFamily: 'Inter_700Bold', marginTop: 6 },
  emptyDesc: { fontSize: 13, fontFamily: 'Inter_400Regular', textAlign: 'center' },
  emptyBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12, marginTop: 8,
  },
  emptyBtnText: { color: '#fff', fontSize: 15, fontFamily: 'Inter_700Bold' },
});
