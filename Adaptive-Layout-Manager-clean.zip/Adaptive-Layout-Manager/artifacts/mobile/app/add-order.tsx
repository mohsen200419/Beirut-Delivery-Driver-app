import React, { useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  TextInput, Platform, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { KeyboardAwareScrollView } from 'react-native-keyboard-controller';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { useLanguage } from '@/context/LanguageContext';
import { Order, Service, Zone } from '@/types';

const TOTAL_STEPS = 4;

export default function AddOrderScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { services, zones, settings, addOrder } = useApp();
  const { t, language } = useLanguage();

  const [step, setStep] = useState(1);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedZone, setSelectedZone] = useState<Zone | null>(null);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [address, setAddress] = useState('');
  const [customValues, setCustomValues] = useState<Record<string, string>>({});
  const [itemPrice, setItemPrice] = useState('');
  const [currency, setCurrency] = useState<'USD' | 'LBP'>('USD');

  const activeServices = services.filter(s => s.is_active);
  const activeZones = zones.filter(z => z.is_active);

  const goNext = () => {
    if (step === 1 && !selectedService) {
      Alert.alert(t('warning'), t('selectServiceError'));
      return;
    }
    if (step === 2 && !selectedZone) {
      Alert.alert(t('warning'), t('selectZoneError'));
      return;
    }
    if (step === 3) {
      if (!customerName.trim()) { Alert.alert(t('warning'), t('customerNameError')); return; }
      if (!customerPhone.trim()) { Alert.alert(t('warning'), t('phoneError')); return; }
      const required = selectedService?.custom_fields.filter(f => f.required) ?? [];
      for (const f of required) {
        if (!customValues[f.id]?.trim()) {
          Alert.alert(
            t('warning'),
            `${t('requiredServiceField')}: ${language === 'ar' ? f.label_ar : f.label_en || f.label_ar}`,
          );
          return;
        }
      }
    }
    if (step < TOTAL_STEPS) setStep(s => s + 1);
  };

  const handleSubmit = () => {
    if (!selectedService || !selectedZone) return;
    const deliveryFee = selectedZone.delivery_fee_usd;
    const itemPriceNum = parseFloat(itemPrice) || 0;
    const totalUsd = itemPriceNum + deliveryFee;
    const totalLbp = Math.round(totalUsd * settings.exchange_rate);
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    const order: Order = {
      id,
      customer_name: customerName.trim(),
      phone: customerPhone.trim(),
      address: address.trim(),
      service_id: selectedService.id,
      zone_id: selectedZone.id,
      submitted_custom_fields: customValues,
      item_price_usd: itemPriceNum,
      delivery_fee_usd: deliveryFee,
      total_usd: totalUsd,
      total_lbp: totalLbp,
      status: 'pending',
      currency,
      created_at: new Date().toISOString(),
    };
    addOrder(order);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.back();
  };

  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 34 : insets.bottom;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 16, backgroundColor: colors.surface }]}>
        <TouchableOpacity onPress={() => router.back()} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Feather name="x" size={24} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>{t('addOrderTitle')}</Text>
        <Text style={[styles.stepLabel, { color: colors.mutedForeground }]}>{step}/{TOTAL_STEPS}</Text>
      </View>

      {/* Progress bar */}
      <View style={[styles.progressBg, { backgroundColor: colors.border }]}>
        <View style={[styles.progressFill, { backgroundColor: colors.primary, width: `${(step / TOTAL_STEPS) * 100}%` }]} />
      </View>

      <KeyboardAwareScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: botPad + 20 }]}
        showsVerticalScrollIndicator={false}
        bottomOffset={20}
      >
        {/* STEP 1: Service */}
        {step === 1 && (
          <View>
            <Text style={[styles.stepTitle, { color: colors.foreground }]}>{t('chooseService')}</Text>
            <View style={styles.serviceGrid}>
              {activeServices.map(service => {
                const sel = selectedService?.id === service.id;
                return (
                  <TouchableOpacity
                    key={service.id}
                    style={[
                      styles.serviceCard,
                      { backgroundColor: sel ? colors.primary : colors.card, borderColor: sel ? colors.primary : colors.border },
                    ]}
                    onPress={() => { setSelectedService(service); setCustomValues({}); }}
                  >
                    <Feather name="package" size={24} color={sel ? '#fff' : colors.primary} />
                    <Text style={[styles.serviceName, { color: sel ? '#fff' : colors.foreground }]}>
                      {language === 'ar' ? service.name_ar : service.name_en || service.name_ar}
                    </Text>
                    <Text style={[styles.serviceNameEn, { color: sel ? 'rgba(255,255,255,0.7)' : colors.mutedForeground }]}>
                      {language === 'ar' ? service.name_en : service.name_ar}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        )}

        {/* STEP 2: Zone */}
        {step === 2 && (
          <View>
            <Text style={[styles.stepTitle, { color: colors.foreground }]}>{t('chooseZone')}</Text>
            {activeZones.map(zone => {
              const sel = selectedZone?.id === zone.id;
              return (
                <TouchableOpacity
                  key={zone.id}
                  style={[
                    styles.zoneRow,
                    { backgroundColor: sel ? colors.primary + '22' : colors.card, borderColor: sel ? colors.primary : colors.border },
                  ]}
                  onPress={() => setSelectedZone(zone)}
                >
                  <View style={styles.zoneLeft}>
                    <Feather name="map-pin" size={16} color={sel ? colors.primary : colors.mutedForeground} />
                    <View>
                        <Text style={[styles.zoneName, { color: colors.foreground }]}>
                          {language === 'ar' ? zone.zone_name_ar : zone.zone_name_en || zone.zone_name_ar}
                        </Text>
                        <Text style={[styles.zoneNameEn, { color: colors.mutedForeground }]}>
                          {language === 'ar' ? zone.zone_name_en : zone.zone_name_ar}
                        </Text>
                    </View>
                  </View>
                  <View style={styles.zoneRight}>
                    <Text style={[styles.zonePrice, { color: sel ? colors.primary : colors.accent }]}>
                      ${zone.delivery_fee_usd}
                    </Text>
                    <Text style={[styles.zonePriceLbp, { color: colors.mutedForeground }]}>
                      {zone.delivery_fee_lbp.toLocaleString()} ل.ل.
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        {/* STEP 3: Customer info + custom fields */}
        {step === 3 && (
          <View>
            <Text style={[styles.stepTitle, { color: colors.foreground }]}>{t('customerData')}</Text>
            <View style={[styles.formCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <InputField label={t('customerName')} value={customerName} onChangeText={setCustomerName} colors={colors} placeholder={t('fullName')} />
              <InputField label={t('phone')} value={customerPhone} onChangeText={setCustomerPhone} colors={colors} placeholder="+96170000000" keyboardType="phone-pad" />
              <InputField label={t('address')} value={address} onChangeText={setAddress} colors={colors} placeholder={t('streetArea')} />
            </View>

            {selectedService && selectedService.custom_fields.length > 0 && (
              <>
                <Text style={[styles.stepSubtitle, { color: colors.foreground }]}>
                  {language === 'ar' ? 'تفاصيل' : language === 'fr' ? 'Détails de' : 'Details for'} {language === 'ar' ? selectedService.name_ar : selectedService.name_en || selectedService.name_ar}
                </Text>
                <View style={[styles.formCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  {selectedService.custom_fields.map(field => (
                    <InputField
                      key={field.id}
                      label={(language === 'ar' ? field.label_ar : field.label_en || field.label_ar) + (field.required ? ' *' : '')}
                      value={customValues[field.id] ?? ''}
                      onChangeText={v => setCustomValues(prev => ({ ...prev, [field.id]: v }))}
                      colors={colors}
                      keyboardType={field.type === 'number' ? 'numeric' : 'default'}
                    />
                  ))}
                </View>
              </>
            )}
          </View>
        )}

        {/* STEP 4: Item price + summary */}
        {step === 4 && selectedService && selectedZone && (
          <View>
            <Text style={[styles.stepTitle, { color: colors.foreground }]}>{t('reviewConfirm')}</Text>

            {/* Summary card */}
            <View style={[styles.summaryCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <SummaryRow label={t('service')} value={language === 'ar' ? selectedService.name_ar : selectedService.name_en || selectedService.name_ar} colors={colors} />
              <SummaryRow label={t('zone')} value={language === 'ar' ? selectedZone.zone_name_ar : selectedZone.zone_name_en || selectedZone.zone_name_ar} colors={colors} />
              <SummaryRow label={t('customerName')} value={customerName} colors={colors} />
              <SummaryRow label={t('phone')} value={customerPhone} colors={colors} />
              {address ? <SummaryRow label={t('address')} value={address} colors={colors} /> : null}
              {Object.entries(customValues).map(([fieldId, val]) => {
                const field = selectedService.custom_fields.find(f => f.id === fieldId);
                return field && val ? <SummaryRow key={fieldId} label={language === 'ar' ? field.label_ar : field.label_en || field.label_ar} value={val} colors={colors} /> : null;
              })}
            </View>

            {/* Item price */}
            <Text style={[styles.stepSubtitle, { color: colors.foreground }]}>{t('itemPriceOptional')}</Text>
            <View style={[styles.formCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <InputField
                label="USD"
                value={itemPrice}
                onChangeText={setItemPrice}
                colors={colors}
                placeholder="0.00"
                keyboardType="numeric"
              />
            </View>

            {/* Currency toggle */}
            <Text style={[styles.stepSubtitle, { color: colors.foreground }]}>{t('paymentCurrency')}</Text>
            <View style={styles.currencyRow}>
              {(['USD', 'LBP'] as const).map(c => (
                <TouchableOpacity
                  key={c}
                  style={[styles.currBtn, { backgroundColor: currency === c ? colors.primary : colors.card, borderColor: colors.border }]}
                  onPress={() => setCurrency(c)}
                >
                  <Text style={[styles.currBtnText, { color: currency === c ? '#fff' : colors.foreground }]}>{c}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Price breakdown */}
            <View style={[styles.priceBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={styles.priceRow}>
                <Text style={[styles.priceLabel, { color: colors.mutedForeground }]}>{t('itemPrice')}</Text>
                <Text style={[styles.priceValue, { color: colors.foreground }]}>${(parseFloat(itemPrice) || 0).toFixed(2)}</Text>
              </View>
              <View style={styles.priceRow}>
                <Text style={[styles.priceLabel, { color: colors.mutedForeground }]}>{t('deliveryFee')}</Text>
                <Text style={[styles.priceValue, { color: colors.foreground }]}>${selectedZone.delivery_fee_usd}</Text>
              </View>
              <View style={[styles.priceDivider, { backgroundColor: colors.border }]} />
              <View style={styles.priceRow}>
                <Text style={[styles.priceTotalLabel, { color: colors.foreground }]}>{t('total')}</Text>
                <View style={styles.priceTotalRight}>
                  <Text style={[styles.priceTotalUsd, { color: colors.accent }]}>
                    ${((parseFloat(itemPrice) || 0) + selectedZone.delivery_fee_usd).toFixed(2)}
                  </Text>
                  <Text style={[styles.priceTotalLbp, { color: colors.mutedForeground }]}>
                    {Math.round(((parseFloat(itemPrice) || 0) + selectedZone.delivery_fee_usd) * settings.exchange_rate).toLocaleString()} ل.ل.
                  </Text>
                </View>
              </View>
            </View>
          </View>
        )}
      </KeyboardAwareScrollView>

      {/* Footer buttons */}
      <View style={[styles.footer, { paddingBottom: botPad + 8, backgroundColor: colors.background, borderTopColor: colors.border }]}>
        {step > 1 && (
          <TouchableOpacity
            style={[styles.backBtn, { borderColor: colors.border }]}
            onPress={() => setStep(s => s - 1)}
          >
            <Feather name="arrow-right" size={20} color={colors.foreground} />
          </TouchableOpacity>
        )}
        {step < TOTAL_STEPS ? (
          <TouchableOpacity style={[styles.nextBtn, { backgroundColor: colors.primary }]} onPress={goNext}>
            <Text style={styles.nextBtnText}>{t('next')}</Text>
            <Feather name={language === 'ar' ? 'arrow-left' : 'arrow-right'} size={18} color="#fff" />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={[styles.nextBtn, { backgroundColor: colors.success }]} onPress={handleSubmit}>
            <Feather name="check" size={18} color="#fff" />
            <Text style={styles.nextBtnText}>{t('confirmOrder')}</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

function InputField({
  label, value, onChangeText, placeholder, keyboardType = 'default', colors,
}: {
  label: string;
  value: string;
  onChangeText: (v: string) => void;
  placeholder?: string;
  keyboardType?: 'default' | 'numeric' | 'phone-pad';
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={[inputStyles.row, { borderBottomColor: colors.border }]}>
      <Text style={[inputStyles.label, { color: colors.mutedForeground }]}>{label}</Text>
      <TextInput
        style={[inputStyles.input, { color: colors.foreground }]}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.mutedForeground}
        keyboardType={keyboardType}
      />
    </View>
  );
}

function SummaryRow({ label, value, colors }: { label: string; value: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={[summaryStyles.row, { borderBottomColor: colors.border }]}>
      <Text style={[summaryStyles.label, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[summaryStyles.value, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

const inputStyles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 13, borderBottomWidth: 1, gap: 10 },
  label: { width: 110, fontSize: 13, fontFamily: 'Inter_500Medium' },
  input: { flex: 1, fontSize: 15, fontFamily: 'Inter_400Regular' },
});

const summaryStyles = StyleSheet.create({
  row: { flexDirection: 'row', paddingVertical: 11, borderBottomWidth: 1 },
  label: { width: 100, fontSize: 13, fontFamily: 'Inter_400Regular' },
  value: { flex: 1, fontSize: 14, fontFamily: 'Inter_600SemiBold' },
});

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 14,
  },
  headerTitle: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  stepLabel: { fontSize: 14, fontFamily: 'Inter_500Medium' },
  progressBg: { height: 3 },
  progressFill: { height: 3 },
  scroll: { padding: 20 },
  stepTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', marginBottom: 18 },
  stepSubtitle: { fontSize: 16, fontFamily: 'Inter_600SemiBold', marginTop: 20, marginBottom: 10 },
  serviceGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  serviceCard: {
    width: '47%',
    borderRadius: 14,
    borderWidth: 1.5,
    padding: 18,
    gap: 8,
    alignItems: 'center',
  },
  serviceName: { fontSize: 15, fontFamily: 'Inter_700Bold', textAlign: 'center' },
  serviceNameEn: { fontSize: 12, fontFamily: 'Inter_400Regular', textAlign: 'center' },
  zoneRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 1.5,
    padding: 14,
    marginBottom: 10,
  },
  zoneLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  zoneName: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  zoneNameEn: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  zoneRight: { alignItems: 'flex-end' },
  zonePrice: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  zonePriceLbp: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  formCard: { borderRadius: 14, borderWidth: 1, paddingHorizontal: 16, overflow: 'hidden' },
  summaryCard: { borderRadius: 14, borderWidth: 1, paddingHorizontal: 16, overflow: 'hidden', marginBottom: 4 },
  currencyRow: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  currBtn: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
  },
  currBtnText: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  priceBox: { borderRadius: 14, borderWidth: 1, padding: 16, gap: 10, marginTop: 4 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  priceLabel: { fontSize: 14, fontFamily: 'Inter_400Regular' },
  priceValue: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  priceDivider: { height: 1, marginVertical: 4 },
  priceTotalLabel: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  priceTotalRight: { alignItems: 'flex-end' },
  priceTotalUsd: { fontSize: 22, fontFamily: 'Inter_700Bold' },
  priceTotalLbp: { fontSize: 13, fontFamily: 'Inter_400Regular' },
  footer: {
    flexDirection: 'row',
    gap: 12,
    padding: 16,
    borderTopWidth: 1,
  },
  backBtn: {
    width: 52,
    height: 52,
    borderRadius: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  nextBtn: {
    flex: 1,
    flexDirection: 'row',
    height: 52,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  nextBtnText: { color: '#fff', fontSize: 16, fontFamily: 'Inter_700Bold' },
});
