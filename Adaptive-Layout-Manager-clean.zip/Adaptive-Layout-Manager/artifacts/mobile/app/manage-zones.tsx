import React, { useState, useEffect } from 'react';
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity,
  TextInput, Platform, Alert, Modal, Switch,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { KeyboardAwareScrollView } from 'react-native-keyboard-controller';
import { useColors } from '@/hooks/useColors';
import { useApp } from '@/context/AppContext';
import { Zone } from '@/types';
import { useLanguage } from '@/context/LanguageContext';

interface ZoneFormProps {
  initial?: Zone;
  exchangeRate: number;
  onSave: (data: Omit<Zone, 'id' | 'is_active'>) => void;
  onCancel: () => void;
}

function ZoneForm({ initial, exchangeRate, onSave, onCancel }: ZoneFormProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { t, language } = useLanguage();
  const botPad = Platform.OS === 'web' ? 34 : insets.bottom;

  const [nameAr, setNameAr] = useState(initial?.zone_name_ar ?? '');
  const [nameEn, setNameEn] = useState(initial?.zone_name_en ?? '');
  const [feeUsd, setFeeUsd] = useState(initial ? String(initial.delivery_fee_usd) : '');
  const [feeLbp, setFeeLbp] = useState(initial ? String(initial.delivery_fee_lbp) : '');
  const [lbpManual, setLbpManual] = useState(false);

  // Auto-calculate LBP from USD when user types USD (unless manually overridden)
  const handleUsdChange = (val: string) => {
    setFeeUsd(val);
    if (!lbpManual) {
      const usdNum = parseFloat(val);
      if (!isNaN(usdNum) && usdNum > 0) {
        const lbpCalc = Math.round(usdNum * exchangeRate / 1000) * 1000; // round to nearest 1000 LL
        setFeeLbp(String(lbpCalc));
      } else {
        setFeeLbp('');
      }
    }
  };

  const handleLbpChange = (val: string) => {
    setFeeLbp(val);
    setLbpManual(true);
  };

  const resetLbpAuto = () => {
    setLbpManual(false);
    const usdNum = parseFloat(feeUsd);
    if (!isNaN(usdNum) && usdNum > 0) {
      setFeeLbp(String(Math.round(usdNum * exchangeRate / 1000) * 1000));
    }
  };

  const handleSave = () => {
    if (!nameAr.trim()) {
      Alert.alert(t('warning'), t('zoneName'));
      return;
    }
    const usd = parseFloat(feeUsd);
    const lbp = parseFloat(feeLbp);
    if (!usd || usd <= 0) {
      Alert.alert(t('warning'), `${t('deliveryPrice')} USD`);
      return;
    }
    if (!lbp || lbp <= 0) {
      Alert.alert(t('warning'), `${t('deliveryPrice')} LBP`);
      return;
    }
    onSave({
      zone_name_ar: nameAr.trim(),
      zone_name_en: nameEn.trim(),
      delivery_fee_usd: usd,
      delivery_fee_lbp: lbp,
    });
  };

  return (
    <View style={[formSt.root, { backgroundColor: colors.background }]}>
      {/* Sheet header */}
      <View style={[formSt.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={onCancel} style={formSt.cancelBtn}>
          <Text style={[formSt.cancelText, { color: colors.primary }]}>{t('cancel')}</Text>
        </TouchableOpacity>
        <Text style={[formSt.title, { color: colors.foreground }]}>
          {initial ? t('editZone') : t('newZone')}
        </Text>
        <TouchableOpacity onPress={handleSave} style={formSt.saveBtn}>
          <Text style={[formSt.saveText, { color: colors.primary }]}>{t('save')}</Text>
        </TouchableOpacity>
      </View>

      <KeyboardAwareScrollView
        contentContainerStyle={[formSt.scroll, { paddingBottom: botPad + 24 }]}
        showsVerticalScrollIndicator={false}
        bottomOffset={20}
      >
        {/* Name section */}
        <Text style={[formSt.sectionLabel, { color: colors.mutedForeground }]}>{t('zoneName')}</Text>
        <View style={[formSt.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[formSt.row, { borderBottomColor: colors.border }]}>
            <Text style={[formSt.rowLabel, { color: colors.mutedForeground }]}>{t('arabicName')} *</Text>
            <TextInput
              style={[formSt.rowInput, { color: colors.foreground }]}
              value={nameAr}
              onChangeText={setNameAr}
              placeholder={language === 'ar' ? 'مثال: وسط بيروت' : language === 'fr' ? 'ex. Centre-ville' : 'e.g. Downtown'}
              placeholderTextColor={colors.mutedForeground}
              textAlign="right"
            />
          </View>
          <View style={[formSt.row, { borderBottomColor: 'transparent' }]}>
            <Text style={[formSt.rowLabel, { color: colors.mutedForeground }]}>English</Text>
            <TextInput
              style={[formSt.rowInput, { color: colors.foreground }]}
              value={nameEn}
              onChangeText={setNameEn}
              placeholder="e.g. Downtown Beirut"
              placeholderTextColor={colors.mutedForeground}
            />
          </View>
        </View>

        {/* Pricing section */}
        <Text style={[formSt.sectionLabel, { color: colors.mutedForeground }]}>{t('deliveryPrice')}</Text>
        <View style={[formSt.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {/* USD */}
          <View style={[formSt.row, { borderBottomColor: colors.border }]}>
            <View style={formSt.currBadge}>
              <Text style={[formSt.currBadgeText, { color: colors.primary }]}>USD</Text>
            </View>
            <TextInput
              style={[formSt.priceInput, { color: colors.foreground }]}
              value={feeUsd}
              onChangeText={handleUsdChange}
              placeholder="0.00"
              placeholderTextColor={colors.mutedForeground}
              keyboardType="decimal-pad"
              textAlign="left"
            />
            <Text style={[formSt.currSymbol, { color: colors.mutedForeground }]}>$</Text>
          </View>

          {/* LBP */}
          <View style={[formSt.row, { borderBottomColor: 'transparent' }]}>
            <View style={[formSt.currBadge, { backgroundColor: colors.accent + '22' }]}>
              <Text style={[formSt.currBadgeText, { color: colors.accent }]}>ل.ل.</Text>
            </View>
            <TextInput
              style={[formSt.priceInput, { color: colors.foreground }]}
              value={feeLbp}
              onChangeText={handleLbpChange}
              placeholder="0"
              placeholderTextColor={colors.mutedForeground}
              keyboardType="number-pad"
              textAlign="left"
            />
            {lbpManual && (
              <TouchableOpacity onPress={resetLbpAuto} style={formSt.autoBtn}>
                <Feather name="refresh-cw" size={14} color={colors.primary} />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Exchange rate hint */}
        <View style={[formSt.hint, { backgroundColor: colors.secondary }]}>
          <Feather name="info" size={14} color={colors.mutedForeground} />
          <Text style={[formSt.hintText, { color: colors.mutedForeground }]}>
            {t('exchangeRate')}:{' '}
            <Text style={{ fontFamily: 'Inter_700Bold', color: colors.foreground }}>
              {exchangeRate.toLocaleString()} ل.ل.
            </Text>
            {' '}{t('perDollar')} — {language === 'ar'
              ? 'يُحتسب السعر بالليرة تلقائياً عند إدخال السعر بالدولار'
              : language === 'fr'
                ? 'Le montant en livres est calculé automatiquement'
                : 'LBP is calculated automatically from USD'}
          </Text>
        </View>
      </KeyboardAwareScrollView>
    </View>
  );
}

export default function ManageZonesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { zones, settings, addZone, updateZone, deleteZone } = useApp();
  const { t, language } = useLanguage();
  const [showModal, setShowModal] = useState(false);
  const [editZone, setEditZone] = useState<Zone | undefined>(undefined);

  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 34 : insets.bottom;

  const openAdd = () => { setEditZone(undefined); setShowModal(true); };
  const openEdit = (z: Zone) => { setEditZone(z); setShowModal(true); };

  const handleSave = (data: Omit<Zone, 'id' | 'is_active'>) => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    if (editZone) {
      updateZone({ ...editZone, ...data });
    } else {
      const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
      addZone({ id, is_active: true, ...data });
    }
    setShowModal(false);
  };

  const confirmDelete = (id: string, name: string) => {
    Alert.alert(`${t('delete')} "${name}"`, language === 'ar' ? 'هل أنت متأكد؟ لا يمكن التراجع عن هذه العملية.' : language === 'fr' ? 'Cette action est irréversible.' : 'This action cannot be undone.', [
      { text: t('cancel'), style: 'cancel' },
      { text: t('delete'), style: 'destructive', onPress: () => deleteZone(id) },
    ]);
  };

  const renderItem = ({ item }: { item: Zone }) => (
    <View style={[st.zoneItem, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={st.zoneMain}>
        <Switch
          value={item.is_active}
          onValueChange={v => updateZone({ ...item, is_active: v })}
          trackColor={{ false: colors.border, true: colors.primary + '55' }}
          thumbColor={item.is_active ? colors.primary : '#9ca3af'}
          ios_backgroundColor={colors.border}
        />
        <View style={st.zoneInfo}>
          <Text style={[st.zoneNameAr, { color: colors.foreground }]}>{item.zone_name_ar}</Text>
          {item.zone_name_en ? (
            <Text style={[st.zoneNameEn, { color: colors.mutedForeground }]}>{item.zone_name_en}</Text>
          ) : null}
        </View>
      </View>
      <View style={st.zoneRight}>
        <Text style={[st.zonePrice, { color: colors.accent }]}>${item.delivery_fee_usd}</Text>
        <Text style={[st.zonePriceLbp, { color: colors.mutedForeground }]}>
          {item.delivery_fee_lbp.toLocaleString()}
        </Text>
        <View style={st.zoneActions}>
          <TouchableOpacity
            onPress={() => openEdit(item)}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
            style={[st.actionBtn, { backgroundColor: colors.primary + '22' }]}
          >
            <Feather name="edit-2" size={15} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => confirmDelete(item.id, item.zone_name_ar)}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
            style={[st.actionBtn, { backgroundColor: colors.destructive + '22' }]}
          >
            <Feather name="trash-2" size={15} color={colors.destructive} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  return (
    <View style={[st.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[st.header, { paddingTop: topPad + 14, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Feather name="arrow-right" size={24} color={colors.foreground} />
        </TouchableOpacity>
        <View>
          <Text style={[st.title, { color: colors.foreground }]}>{t('zones')}</Text>
          <Text style={[st.subtitle, { color: colors.mutedForeground }]}>{zones.length} {t('zoneCount')}</Text>
        </View>
        <TouchableOpacity
          style={[st.addBtn, { backgroundColor: colors.primary }]}
          onPress={openAdd}
          activeOpacity={0.8}
        >
          <Feather name="plus" size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Table header */}
      {zones.length > 0 && (
        <View style={[st.tableHeader, { backgroundColor: colors.secondary }]}>
          <Text style={[st.th, { color: colors.mutedForeground, flex: 1 }]}>{t('zone')}</Text>
          <Text style={[st.th, { color: colors.mutedForeground }]}>{t('deliveryFeeLabel')}</Text>
          <Text style={[st.th, { color: colors.mutedForeground, marginLeft: 8 }]}>{t('action')}</Text>
        </View>
      )}

      <FlatList
        data={zones}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={[
          st.list,
          { paddingBottom: botPad + 20 },
          zones.length === 0 && st.emptyList,
        ]}
        ListEmptyComponent={
          <View style={st.emptyContainer}>
            <View style={[st.emptyIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="map-pin" size={40} color={colors.primary} />
            </View>
            <Text style={[st.emptyTitle, { color: colors.foreground }]}>
              {t('noZonesYet')}
            </Text>
            <Text style={[st.emptyDesc, { color: colors.mutedForeground }]}>
              {t('addZonesDescription')}{'\n'}
              {language === 'ar' ? 'يمكنك تفعيل أو تعطيل أي منطقة في أي وقت.' : language === 'fr' ? 'Activez ou désactivez chaque zone à tout moment.' : 'Enable or disable any area at any time.'}
            </Text>
            <TouchableOpacity
              style={[st.emptyAction, { backgroundColor: colors.primary }]}
              onPress={openAdd}
              activeOpacity={0.8}
            >
              <Feather name="plus" size={18} color="#fff" />
              <Text style={st.emptyActionText}>{t('addFirstZone')}</Text>
            </TouchableOpacity>
          </View>
        }
        showsVerticalScrollIndicator={false}
      />

      {/* Zone form modal */}
      <Modal visible={showModal} animationType="slide" presentationStyle="pageSheet">
        <ZoneForm
          initial={editZone}
          exchangeRate={settings.exchange_rate}
          onSave={handleSave}
          onCancel={() => setShowModal(false)}
        />
      </Modal>
    </View>
  );
}

const formSt = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 14,
    borderBottomWidth: 1,
  },
  cancelBtn: { paddingVertical: 4, paddingHorizontal: 2 },
  cancelText: { fontSize: 16, fontFamily: 'Inter_500Medium' },
  title: { fontSize: 17, fontFamily: 'Inter_700Bold' },
  saveBtn: { paddingVertical: 4, paddingHorizontal: 2 },
  saveText: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  scroll: { padding: 20 },
  sectionLabel: {
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: 8,
    marginTop: 20,
    marginRight: 4,
  },
  card: {
    borderRadius: 14,
    borderWidth: 1,
    overflow: 'hidden',
    paddingHorizontal: 16,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 13,
    borderBottomWidth: 1,
    gap: 10,
  },
  rowLabel: { width: 70, fontSize: 14, fontFamily: 'Inter_500Medium' },
  rowInput: { flex: 1, fontSize: 16, fontFamily: 'Inter_400Regular', paddingVertical: 0 },
  currBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: '#3b82f622',
    minWidth: 50,
    alignItems: 'center',
  },
  currBadgeText: { fontSize: 13, fontFamily: 'Inter_700Bold' },
  priceInput: { flex: 1, fontSize: 20, fontFamily: 'Inter_700Bold', paddingVertical: 0 },
  currSymbol: { fontSize: 16, fontFamily: 'Inter_600SemiBold' },
  autoBtn: { padding: 6 },
  hint: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    borderRadius: 10,
    padding: 12,
    marginTop: 12,
  },
  hintText: { flex: 1, fontSize: 13, fontFamily: 'Inter_400Regular', lineHeight: 20 },
});

const st = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 14,
    borderBottomWidth: 1,
  },
  title: { fontSize: 20, fontFamily: 'Inter_700Bold', textAlign: 'center' },
  subtitle: { fontSize: 12, fontFamily: 'Inter_400Regular', textAlign: 'center', marginTop: 2 },
  addBtn: {
    width: 40, height: 40, borderRadius: 20,
    justifyContent: 'center', alignItems: 'center',
  },
  tableHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  th: { fontSize: 11, fontFamily: 'Inter_600SemiBold', textTransform: 'uppercase', letterSpacing: 0.5 },
  list: { padding: 12 },
  emptyList: { flex: 1, justifyContent: 'center' },
  zoneItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1,
    paddingLeft: 12,
    paddingRight: 10,
    paddingVertical: 12,
    marginBottom: 10,
  },
  zoneMain: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  zoneInfo: { flex: 1 },
  zoneNameAr: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  zoneNameEn: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  zoneRight: { alignItems: 'flex-end', gap: 4 },
  zonePrice: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  zonePriceLbp: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  zoneActions: { flexDirection: 'row', gap: 6, marginTop: 4 },
  actionBtn: { width: 30, height: 30, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
  emptyContainer: { alignItems: 'center', padding: 32, gap: 16 },
  emptyIcon: { width: 80, height: 80, borderRadius: 40, justifyContent: 'center', alignItems: 'center' },
  emptyTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', textAlign: 'center' },
  emptyDesc: { fontSize: 14, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 22 },
  emptyAction: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: 28, paddingVertical: 14, borderRadius: 14, marginTop: 8,
  },
  emptyActionText: { color: '#fff', fontSize: 16, fontFamily: 'Inter_700Bold' },
});
